package modelo;

import java.time.LocalDateTime;
import java.util.HashMap;

public class Operacion {

    private Cliente parte_1;
    private Cliente parte_2;
    private LocalDateTime fechaHora;
    private boolean esta_activa;

    private static int contadorID = 0;
    private int id;

    private String tiquet_id;

    // -----------------------------------------
    // CONSTRUCTOR
    // -----------------------------------------
    public Operacion(Cliente parte_1, Cliente parte_2, boolean esta_activa, String tiquet_id) {
        this.parte_1 = parte_1;
        this.parte_2 = parte_2;
        this.esta_activa = esta_activa;
        this.fechaHora = LocalDateTime.now();
        this.tiquet_id = tiquet_id;
        this.id = ++contadorID;
    }

    // -----------------------------------------
    // GETTERS
    // -----------------------------------------
    public Cliente getParte_1() { return parte_1; }
    public Cliente getParte_2() { return parte_2; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public boolean isEsta_activa() { return esta_activa; }
    public static int getContadorID() { return contadorID; }
    public int getId() { return id; }
    public String getTiquet_id() { return tiquet_id; }

    // -----------------------------------------
    // MARKETPLACE
    // -----------------------------------------
    public void publicar_oferta_Tiquete(Administrador admin) {

        Tiquete tiquete = buscarTiqueteDeParte1();

        if (tiquete != null && tiquete.isEsTransferible()) {

            parte_1.getTiquetes().remove(tiquete);

            parte_1.getSolicitudes_market_place().put(this.id, this);

            HashMap<LocalDateTime, Operacion> log = admin.getLog_registros();
            log.put(fechaHora, this);
        }
    }

    public void borrar_oferta(Administrador admin) {
        this.esta_activa = false;

        Tiquete tiquete = buscarTiqueteDeParte1();

        // quitar solicitud
        parte_1.getSolicitudes_market_place().remove(this.id);

        // devolver tiquete
        if (tiquete != null) {
            parte_1.getTiquetes().add(tiquete);
        }
    }

    public void comprar_tiquete(Administrador admin, Cliente comprador) {

        this.esta_activa = false;

        Tiquete tiquete = buscarTiqueteDeParte1();
        if (tiquete == null) return;

        // crear nueva operación cerrada
        Operacion nueva = new Operacion(parte_1, comprador, false, tiquet_id);
        admin.getLog_registros().put(nueva.getFechaHora(), nueva);

        // cobrar
        comprador.setSaldoPlataforma(
                comprador.getSaldoPlataforma() - tiquete.getPrecio()
        );

        // entregar tiquete
        comprador.getTiquetes().add(tiquete);
    }

    public void contra_ofertar(Administrador admin, Cliente comprador, double valor) {

        Tiquete tiquete = buscarTiqueteDeParte1();
        if (tiquete == null) return;

        tiquete.setPrecio(valor);

        Operacion nueva = new Operacion(parte_1, comprador, true, tiquet_id);

        parte_1.getSolicitudes_market_place().put(nueva.getId(), nueva);
        admin.getLog_registros().put(nueva.getFechaHora(), nueva);
    }

    public void aceptar_contra_oferta(Administrador admin) {

        this.esta_activa = false;

        Tiquete tiquete = buscarTiqueteDeParte1();
        if (tiquete == null) return;

        Operacion nueva = new Operacion(parte_1, parte_2, false, tiquet_id);
        admin.getLog_registros().put(nueva.getFechaHora(), nueva);

        parte_2.setSaldoPlataforma(
                parte_2.getSaldoPlataforma() - tiquete.getPrecio()
        );

        parte_2.getTiquetes().add(tiquete);
        parte_1.getSolicitudes_market_place().remove(this.getId());
    }

    public void rechazar_contra_oferta(Administrador admin) {
        this.esta_activa = false;

        Operacion nueva = new Operacion(parte_1, parte_2, false, tiquet_id);
        parte_1.getSolicitudes_market_place().remove(this.getId());
        admin.getLog_registros().put(nueva.getFechaHora(), nueva);
    }

    // -----------------------------------------
    // UTIL
    // -----------------------------------------
    private Tiquete buscarTiqueteDeParte1() {
        for (Tiquete t : parte_1.getTiquetes()) {
            if (t.getIdentificador().equals(tiquet_id)) {
                return t;
            }
        }
        return null;
    }

    // -----------------------------------------
    // TO STRING
    // -----------------------------------------
    @Override
    public String toString() {
        String c1 = (parte_1 != null) ? parte_1.getLogin() : "—";
        String c2 = (parte_2 != null) ? parte_2.getLogin() : "—";

        return "ID=" + id +
               " | Cliente1=" + c1 +
               " | Cliente2=" + c2 +
               " | Ticket=" + tiquet_id +
               " | Activa=" + esta_activa;
    }

    // -----------------------------------------
    // SETTERS
    // -----------------------------------------
    public void setParte_1(Cliente parte_1) { this.parte_1 = parte_1; }
    public void setParte_2(Cliente parte_2) { this.parte_2 = parte_2; }
}
