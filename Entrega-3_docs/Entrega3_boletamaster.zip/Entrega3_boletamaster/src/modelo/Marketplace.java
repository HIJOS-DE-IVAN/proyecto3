package modelo;

import java.util.HashMap;

public class Marketplace {
	public HashMap<String, Operacion> log_registros; //el string es la fecha + hora, el client
	
	public HashMap<String,Operacion> Marketplace(){
		return log_registros;
	}
	

}
