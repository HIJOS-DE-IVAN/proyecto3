package pruebasUnitarias;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import modelo.Tiquete;
import modelo.TiqueteMultiplesPalco;
public class TiqueteMultiplePalcoTest {


	    private TiqueteMultiplesPalco paquete;

	    @BeforeEach
	    void setUp() {
	        paquete = new TiqueteMultiplesPalco(5, 250_000.0);
	    }

	    @AfterEach
	    void tearDown() {
	        paquete = null;
	    }
	    // Constructor: inicializa campos y lista
	    @Test
	    void testConstructor_InicializaCamposYLista() {
	        assertEquals(5, paquete.getCantidad(), "Cantidad inicial incorrecta");
	        assertEquals(250_000.0, paquete.getPrecio(), 1e-9, "Precio inicial incorrecto");

	    }
	    // Setters básicos
	    @Test
	    void testSetCantidad_ModificaValor() {
	        paquete.setCantidad(10);
	        assertEquals(10, paquete.getCantidad(), "No se actualizó la cantidad correctamente");
	    }

	    @Test
	    void testSetPrecio_ModificaValor() {
	        paquete.setPrecio(300_000.0);
	        assertEquals(300_000.0, paquete.getPrecio(), 1e-9, "No se actualizó el precio correctamente");
	    }
	    // Lista de tiquetes: referencia y mutación externa
	    @Test
	    void testSetTiquetes_AsignaReferencia() {
	        ArrayList<Tiquete> lista = new ArrayList<>();
	    }

	}

