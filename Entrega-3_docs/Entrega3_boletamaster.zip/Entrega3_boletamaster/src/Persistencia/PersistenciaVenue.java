package Persistencia;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import modelo.Venue;

import org.json.JSONArray;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class PersistenciaVenue {

    private static final Path RUTA = obtenerRutaVenue();
    
    private static final Gson gson = new GsonBuilder()
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ssX")
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    private static Path obtenerRutaVenue() {
        try {
        	return Paths.get("datos", "venues.json");
        } catch (Exception e) {
            throw new RuntimeException("No se pudo obtener la ruta del archivo eventos.json", e);
        }
    }

    public List<Venue> cargarVenues() {
        try {
            if (!Files.exists(RUTA)) return new ArrayList<>();
            String texto = Files.readString(RUTA, StandardCharsets.UTF_8).trim();
            if (texto.isEmpty()) return new ArrayList<>();
            new JSONArray(texto);
            Venue[] arr = gson.fromJson(texto, Venue[].class);
            return (arr != null) ? new ArrayList<>(Arrays.asList(arr)) : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void guardarVenues(List<Venue> venues) {
        try {
            Path dir = RUTA.getParent();
            if (!Files.exists(dir)) Files.createDirectories(dir);
            String json = gson.toJson(venues);
            new JSONArray(json);
            Files.writeString(RUTA, json, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar venues.json", e);
        }
    }
}
