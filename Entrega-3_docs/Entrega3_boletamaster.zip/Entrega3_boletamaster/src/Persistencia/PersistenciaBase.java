package Persistencia;

import com.google.gson.Gson;
import org.json.JSONArray;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Persistencia.PersistenciaLocalidad;


public final class PersistenciaBase {

    private PersistenciaLocalidad persistenciaLocalidad;
    private PersistenciaUsuarios persistenciaCliente;
    private PersistenciaEvento persistenciaEvento;
    private PersistenciaVenue persistenciaVenue;
    
    public PersistenciaBase() {
    	persistenciaLocalidad = new PersistenciaLocalidad();
    	persistenciaCliente = new PersistenciaUsuarios();
    	persistenciaEvento = new PersistenciaEvento();
    	persistenciaVenue = new PersistenciaVenue();
    }
    
}
