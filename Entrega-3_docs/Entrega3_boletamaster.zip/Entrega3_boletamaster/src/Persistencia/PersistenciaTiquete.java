package Persistencia;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import modelo.Cliente;
import modelo.Localidad;
import modelo.Tiquete;
import modelo.TiqueteMultipleDeluxe;
import modelo.TiqueteMultipleTemporada;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class PersistenciaTiquete {
	
	private static final Gson GSON = new GsonBuilder()
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ss")
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .create();


    private static final DateTimeFormatter ISO_LOCAL = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final Path RUTA = obtenerRutaTiquete();
    private static final Path RUTA_TMD = obtenerRutaTiqueteMD();
    private static final Path RUTA_TMT = obtenerRutaTiqueteMT();


    private static Path obtenerRutaTiquete() {
        try {
        	return Paths.get("datos", "tiquete.json");
        } catch (Exception e) {
            throw new RuntimeException("No se pudo obtener la ruta del archivo eventos.json", e);
        }
    }
    
    private static Path obtenerRutaTiqueteMD() {
        try {
        	return Paths.get("datos", "tiqueteMDeluxe.json");
        } catch (Exception e) {
            throw new RuntimeException("No se pudo obtener la ruta del archivo eventos.json", e);
        }
    }
    
    private static Path obtenerRutaTiqueteMT() {
        try {
        	return Paths.get("datos", "tiqueteMTemporada.json");
        } catch (Exception e) {
            throw new RuntimeException("No se pudo obtener la ruta del archivo eventos.json", e);
        }
    }

    public List<Tiquete> cargarTiquetes(Map<String, Cliente> usuariosPorLogin,
                                        Map<String, Localidad> localidadesPorNombre) {
        List<Tiquete> lista = new ArrayList<>();
        try {
            if (!Files.exists(RUTA)) return lista;

            String texto = Files.readString(RUTA, StandardCharsets.UTF_8);
            if (texto == null) texto = "";
            if (!texto.isEmpty() && texto.charAt(0) == '\uFEFF') texto = texto.substring(1);
            texto = texto.trim();
            if (texto.isEmpty()) return lista;

            JSONArray arr = new JSONArray(texto);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);

                String identificador = optString(o, "identificador", UUID.randomUUID().toString());
                String fechaStr      = optString(o, "fecha", "2025-01-01T00:00:00");
                int hora             = o.optInt("hora", 0);
                double precio        = o.optDouble("precio", 0.0);
                double sobrePorc     = o.optDouble("sobrecargo_porcentual_servicio", 0.0);
                double cuotaFija     = o.optDouble("cuota_fija", 0.0);
                boolean transferible = o.optBoolean("esTransferible", false);
                boolean vendido      = o.optBoolean("estaVendido", false);

                String clienteLogin   = optString(o, "clienteLogin", null);
                String localidadNombre= optString(o, "localidadNombre", null);

                Date fecha = parseDate(fechaStr);

                Localidad loc = (localidadNombre != null) ? localidadesPorNombre.get(localidadNombre) : null;
                Cliente cli   = (clienteLogin != null) ? usuariosPorLogin.get(clienteLogin) : null;

                Tiquete t = new Tiquete(sobrePorc, cuotaFija, identificador, fecha, hora, loc, precio, transferible, vendido, cli);

                // (Opcional) tiquetesMultiplesPalco: si lo tienes y quieres persistirlo, podrías mapear aquí
                // Por ahora ignoramos su contenido o lo dejas vacío.

                lista.add(t);
            }

            return lista;
        } catch (Exception e) {
            System.out.println("[PersistenciaTiquete] Error cargando tiquetes: " + e.getMessage());
            return lista;
        }
    }

    public void guardarTiquetes(List<Tiquete> tiquetes) {
        try {
            Path dir = RUTA.getParent();
            if (dir != null && !Files.exists(dir)) Files.createDirectories(dir);

            JSONArray arr = new JSONArray();

            for (Tiquete t : tiquetes) {
                JSONObject o = new JSONObject();
                o.put("identificador", t.getIdentificador() != null ? t.getIdentificador() : UUID.randomUUID().toString());

                Date f = getField(t, "fecha", Date.class);
                String fechaStr = (f != null)
                        ? ISO_LOCAL.format(LocalDateTime.ofInstant(f.toInstant(), ZoneId.systemDefault()))
                        : "2025-01-01T00:00:00";
                o.put("fecha", fechaStr);

                o.put("hora", getIntField(t, "hora"));
                o.put("precio", t.getPrecio());
                o.put("sobrecargo_porcentual_servicio", getDoubleField(t, "sobrecargo_porcentual_servicio"));
                o.put("cuota_fija", getDoubleField(t, "cuota_fija"));
                o.put("esTransferible", t.isEsTransferible());
                o.put("estaVendido", t.isEstaVendido());

                String clienteLogin = (t.getCliente() != null) ? t.getCliente().getLogin() : null;
                String localidadNombre = (t.getLocalidad() != null) ? t.getLocalidad().getNombre() : null;
                if (clienteLogin != null) o.put("clienteLogin", clienteLogin);
                if (localidadNombre != null) o.put("localidadNombre", localidadNombre);

                o.put("tiquetesMultiplesPalco", new JSONArray());

                arr.put(o);
            }

            Files.writeString(RUTA, arr.toString(2), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar tiquetes.json", e);
        }
    }

    private static String optString(JSONObject o, String key, String def) {
        try { return o.has(key) && !o.isNull(key) ? o.getString(key) : def; }
        catch (Exception ignored) { return def; }
    }

    private static Date parseDate(String isoLocal) {
        try {
            LocalDateTime ldt = LocalDateTime.parse(isoLocal, ISO_LOCAL);
            return Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
        } catch (Exception e) {
            return new Date(0L);
        }
    }

    private static <T> T getField(Object obj, String fieldName, Class<T> type) {
        try {
            var f = obj.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            Object v = f.get(obj);
            return type.isInstance(v) ? type.cast(v) : null;
        } catch (Exception e) {
            return null;
        }
    }
    private static int getIntField(Object obj, String fieldName) {
        try {
            var f = obj.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            Object v = f.get(obj);
            return (v instanceof Integer) ? (Integer) v : 0;
        } catch (Exception e) {
            return 0;
        }
    }
    private static double getDoubleField(Object obj, String fieldName) {
        try {
            var f = obj.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            Object v = f.get(obj);
            return (v instanceof Double) ? (Double) v : 0.0;
        } catch (Exception e) {
            return 0.0;
        }
    }
    
    public List<TiqueteMultipleDeluxe> cargarTiquetesMultipleDeluxe() {
        try {
            if (!Files.exists(RUTA_TMD)) return new ArrayList<>();
            String texto = Files.readString(RUTA_TMD, StandardCharsets.UTF_8).trim();
            if (texto.isEmpty()) return new ArrayList<>();
            new JSONArray(texto);
            TiqueteMultipleDeluxe[] arr = GSON.fromJson(texto, TiqueteMultipleDeluxe[].class);
            return (arr != null) ? new ArrayList<>(Arrays.asList(arr)) : new ArrayList<>();
        } catch (Exception e) {
        	e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void guardarTiquetesMultipleDeluxe(List<TiqueteMultipleDeluxe> tiquetes) {
        try {
            Path dir = RUTA_TMD.getParent();
            if (dir != null && !Files.exists(dir)) Files.createDirectories(dir);
            String json = GSON.toJson(tiquetes);
            new JSONArray(json);
            Files.writeString(RUTA_TMD, json, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar tiquetes_multiple_deluxe.json", e);
        }
    }
    
    public List<TiqueteMultipleTemporada> cargarTiquetesMultipleTemporada() {
        try {
            if (!Files.exists(RUTA_TMT)) return new ArrayList<>();
            String texto = Files.readString(RUTA_TMT, StandardCharsets.UTF_8).trim();
            if (texto.isEmpty()) return new ArrayList<>();
            new JSONArray(texto);
            TiqueteMultipleTemporada[] arr = GSON.fromJson(texto, TiqueteMultipleTemporada[].class);
            return (arr != null) ? new ArrayList<>(Arrays.asList(arr)) : new ArrayList<>();
        } catch (Exception e) {
        	e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void guardarTiquetesMultipleTemporada(List<TiqueteMultipleTemporada> tiquetes) {
        try {
            Path dir = RUTA_TMT.getParent();
            if (dir != null && !Files.exists(dir)) Files.createDirectories(dir);
            String json = GSON.toJson(tiquetes);
            new JSONArray(json);
            Files.writeString(RUTA_TMT, json, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar tiquetes_multiple_deluxe.json", e);
        }
    }


    
}
