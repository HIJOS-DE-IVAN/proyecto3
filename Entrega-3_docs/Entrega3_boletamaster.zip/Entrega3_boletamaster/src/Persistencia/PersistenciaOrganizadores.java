
package Persistencia;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import modelo.OrganizadorDeEventos;

import org.json.JSONArray;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class PersistenciaOrganizadores {

    private static final Path RUTA = obtenerRutaOrganizadores();
    
    private static final Gson gson = new GsonBuilder()
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ssX")
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    private static Path obtenerRutaOrganizadores() {
        try {
        	return Paths.get("datos", "organizadores.json");
        } catch (Exception e) {
            throw new RuntimeException("No se pudo obtener la ruta del archivo eventos.json", e);
        }
    }
    
    public List<OrganizadorDeEventos> cargarOrganizadores() {
        try {
            if (!Files.exists(RUTA)) return new ArrayList<>();
            String texto = Files.readString(RUTA, StandardCharsets.UTF_8).trim();
            if (texto.isEmpty()) return new ArrayList<>();
            new JSONArray(texto);
            OrganizadorDeEventos[] arr = gson.fromJson(texto, OrganizadorDeEventos[].class);
            return (arr != null) ? new ArrayList<>(Arrays.asList(arr)) : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void guardarOrganizadores(List<OrganizadorDeEventos> eventos) {
        try {
            Path dir = RUTA.getParent();
            if (!Files.exists(dir)) Files.createDirectories(dir);
            String json = gson.toJson(eventos);
            new JSONArray(json);
            Files.writeString(RUTA, json, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar organizadores.json", e);
        }
    }
}
