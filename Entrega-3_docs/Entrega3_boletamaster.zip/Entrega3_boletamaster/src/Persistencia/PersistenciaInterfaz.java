package Persistencia;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.*;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import modelo.*;

public class PersistenciaInterfaz {

	private static final Gson gson = new GsonBuilder()
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ssX")
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    /**
     * Carga la lista de clientes desde clientes.json
     * y les deja el admin "ligero" (solo login/password).
     */
	public static List<Cliente> cargarClientes(String rutaClientes) throws IOException {
	    try (FileReader reader = new FileReader(rutaClientes)) {
	        JsonArray arr = JsonParser.parseReader(reader).getAsJsonArray();
	        List<Cliente> clientes = new ArrayList<>();

	        for (JsonElement el : arr) {
	            JsonObject o = el.getAsJsonObject();

	            String login = o.get("login").getAsString();
	            String password = o.get("password").getAsString();
	            double saldo = o.get("saldoPlataforma").getAsDouble();

	            Cliente c = new Cliente(login, password, saldo);

	            List<Tiquete> tiquetes = new ArrayList<>();
	            JsonArray tiqArr = o.getAsJsonArray("tiquetes");
	            if (tiqArr != null) {
	                for (JsonElement tEl : tiqArr) {
	                    Tiquete t = gson.fromJson(tEl, Tiquete.class);
	                    tiquetes.add(t);
	                }
	            }
	            c.setTiquetes(tiquetes);

	            clientes.add(c);
	        }

	        return clientes;
	    }
	}


    /**
     * Guarda la lista de clientes en clientes.json
     * Evita ciclos serializando sólo login/password del admin.
     */
	public static void guardarClientes(String rutaClientes, List<Cliente> clientes) throws IOException {
	    JsonArray arr = new JsonArray();

	    for (Cliente c : clientes) {
	        JsonObject o = new JsonObject();
	        o.addProperty("login", c.getLogin());
	        o.addProperty("password", c.getPassword());
	        o.addProperty("saldoPlataforma", c.getSaldoPlataforma());

	        JsonArray tiqArr = new JsonArray();
	        if (c.getTiquetes() != null) {
	            for (Tiquete t : c.getTiquetes()) {
	                JsonElement tJson = gson.toJsonTree(t);
	                tiqArr.add(tJson);
	            }
	        }
	        o.add("tiquetes", tiqArr);


	        arr.add(o);
	    }

	    try (FileWriter writer = new FileWriter(rutaClientes)) {
	        gson.toJson(arr, writer);
	    }
	}


    /**
     * Carga el administrador completo desde admin.json.
     * NO toma mapa_clientes del JSON: lo reconstruye desde la lista de clientes.
     */
    public static Administrador cargarAdministrador(String rutaAdmin, List<Cliente> clientes) throws IOException {
        try (FileReader reader = new FileReader(rutaAdmin)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

            String login = root.get("login").getAsString();
            String password = root.get("password").getAsString();

            Administrador admin = new Administrador(login, password);

            // ---- mapa_eventos ----
            if (root.has("mapa_eventos") && root.get("mapa_eventos").isJsonObject()) {
                JsonObject mapaEventosJson = root.getAsJsonObject("mapa_eventos");
                Type typeMapaEventos = new TypeToken<HashMap<String, Evento>>() {}.getType();
                admin.mapa_eventos = gson.fromJson(mapaEventosJson, typeMapaEventos);
            } else {
                admin.mapa_eventos = new HashMap<>();
            }

            // ---- mapa_venues ----
            if (root.has("mapa_venues") && root.get("mapa_venues").isJsonObject()) {
                JsonObject mapaVenuesJson = root.getAsJsonObject("mapa_venues");
                Type typeMapaVenues = new TypeToken<HashMap<String, Venue>>() {}.getType();
                admin.mapa_venues = gson.fromJson(mapaVenuesJson, typeMapaVenues);
            } else {
                admin.mapa_venues = new HashMap<>();
            }

            // ---- mapa_localidades (LO IMPORTANTE AHORA) ----
            if (root.has("mapa_localidades") && root.get("mapa_localidades").isJsonObject()) {
                JsonObject mapaLocJson = root.getAsJsonObject("mapa_localidades");
                Type typeMapaLoc = new TypeToken<HashMap<String, Localidad>>() {}.getType();
                admin.mapa_localidades = gson.fromJson(mapaLocJson, typeMapaLoc);
            } else {
                admin.mapa_localidades = new HashMap<>();
            }

            // ---- mapa_solicitudes ----
            if (root.has("mapa_solicitudes") && root.get("mapa_solicitudes").isJsonObject()) {
                JsonObject mapaSolicitudesJson = root.getAsJsonObject("mapa_solicitudes");
                Type typeMapaSolicitudes = new TypeToken<HashMap<String, String>>() {}.getType();
                admin.mapa_solicitudes = gson.fromJson(mapaSolicitudesJson, typeMapaSolicitudes);
            } else {
                admin.mapa_solicitudes = new HashMap<>();
            }

            // ---- mapa_venues_sugeridos ----
            if (root.has("mapa_venues_sugeridos") && root.get("mapa_venues_sugeridos").isJsonObject()) {
                JsonObject mapaVenuesSugJson = root.getAsJsonObject("mapa_venues_sugeridos");
                Type typeMapaVenuesSug = new TypeToken<HashMap<String, Venue>>() {}.getType();
                admin.mapa_venues_sugeridos = gson.fromJson(mapaVenuesSugJson, typeMapaVenuesSug);
            } else {
                admin.mapa_venues_sugeridos = new HashMap<>();
            }

            // ---- reconstruir mapa_clientes desde lista de clientes ----
            HashMap<String, Cliente> mapaClientes = new HashMap<>();
            for (Cliente c : clientes) {
                mapaClientes.put(c.getLogin(), c);
                c.setAdmin(admin); // todos cuelgan de este admin
            }
            admin.mapa_clientes = mapaClientes;
            
         // ---- clientes_inscritos_marketplace ----
            if (root.has("clientes_inscritos_marketplace") && root.get("clientes_inscritos_marketplace").isJsonObject()) {
                JsonObject clientesMkJson = root.getAsJsonObject("clientes_inscritos_marketplace");
                Type typeClientesMk = new TypeToken<HashMap<String, Cliente>>() {}.getType();
                HashMap<String, Cliente> clientesMk = gson.fromJson(clientesMkJson, typeClientesMk);
                admin.setClientes_inscritos_marketplace(clientesMk);
            } else {
                admin.setClientes_inscritos_marketplace(new HashMap<>());
            }

            // ---- solicitudes_promotor_marketplace ----
            if (root.has("solicitudes_promotor_marketplace") && root.get("solicitudes_promotor_marketplace").isJsonObject()) {
                JsonObject solPromJson = root.getAsJsonObject("solicitudes_promotor_marketplace");
                Type typeSolProm = new TypeToken<HashMap<String, OrganizadorDeEventos>>() {}.getType();
                HashMap<String, OrganizadorDeEventos> solProm = gson.fromJson(solPromJson, typeSolProm);
                admin.setSolicitudes_promotor_marketplace(solProm);
            } else {
                admin.setSolicitudes_promotor_marketplace(new HashMap<>());
            }

            // ---- promotor_inscritos_marketplace ----
            if (root.has("promotor_inscritos_marketplace") && root.get("promotor_inscritos_marketplace").isJsonObject()) {
                JsonObject promInsJson = root.getAsJsonObject("promotor_inscritos_marketplace");
                Type typePromIns = new TypeToken<HashMap<String, OrganizadorDeEventos>>() {}.getType();
                HashMap<String, OrganizadorDeEventos> promIns = gson.fromJson(promInsJson, typePromIns);
                admin.setPromotor_inscritos_marketplace(promIns);
            } else {
                admin.setPromotor_inscritos_marketplace(new HashMap<>());
            }
            
         // ---- log_registros (OPERACIONES DEL MARKETPLACE) ----
            if (root.has("log_registros") && root.get("log_registros").isJsonObject()) {
                JsonObject logJson = root.getAsJsonObject("log_registros");

                HashMap<LocalDateTime, Operacion> mapaLog = new HashMap<>();

                for (Map.Entry<String, JsonElement> entry : logJson.entrySet()) {
                    JsonElement value = entry.getValue();
                    Operacion op = gson.fromJson(value, Operacion.class);
                    if (op != null && op.getFechaHora() != null) {
                        mapaLog.put(op.getFechaHora(), op);
                    }
                }

                admin.setLog_registros(mapaLog);
            } else {
                admin.setLog_registros(new HashMap<>());
            }




            return admin;
        }
    }


    /**
     * Guarda el administrador completo en admin.json.
     * NO escribe mapa_clientes para evitar ciclos y duplicación;
     * se reconstruye siempre que se cargue desde los clientes.
     */
    public static void guardarAdministrador(String rutaAdmin, Administrador admin) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("login", admin.getLogin());
        root.addProperty("password", admin.getPassword());

        // mapa_eventos
        if (admin.mapa_eventos != null) {
            JsonElement mapaEventosJson = gson.toJsonTree(admin.mapa_eventos);
            root.add("mapa_eventos", mapaEventosJson);
        } else {
            root.add("mapa_eventos", new JsonObject());
        }

        // mapa_venues
        if (admin.mapa_venues != null) {
            JsonElement mapaVenuesJson = gson.toJsonTree(admin.mapa_venues);
            root.add("mapa_venues", mapaVenuesJson);
        } else {
            root.add("mapa_venues", new JsonObject());
        }

        // mapa_solicitudes
        if (admin.mapa_solicitudes != null) {
            JsonElement mapaSolicitudesJson = gson.toJsonTree(admin.mapa_solicitudes);
            root.add("mapa_solicitudes", mapaSolicitudesJson);
        } else {
            root.add("mapa_solicitudes", new JsonObject());
        }

        // mapa_venues_sugeridos
        if (admin.mapa_venues_sugeridos != null) {
            JsonElement mapaVenuesSugJson = gson.toJsonTree(admin.mapa_venues_sugeridos);
            root.add("mapa_venues_sugeridos", mapaVenuesSugJson);
        } else {
            root.add("mapa_venues_sugeridos", new JsonObject());
        }

        // Si en el futuro decides persistir log_registros o marketplace,
        // aquí añades esos campos.

        try (FileWriter writer = new FileWriter(rutaAdmin)) {
            gson.toJson(root, writer);
        }
        
    }
    
    public static List<OrganizadorDeEventos> cargarOrganizadores(String rutaOrganizadores,
            Administrador admin) throws IOException {
		List<OrganizadorDeEventos> resultado = new ArrayList<>();
		
		try (FileReader reader = new FileReader(rutaOrganizadores)) {
		JsonArray arr = JsonParser.parseReader(reader).getAsJsonArray();
		
		for (JsonElement el : arr) {
		JsonObject o = el.getAsJsonObject();
		
		String login = o.get("login").getAsString();
		String password = o.get("password").getAsString();
		
		// Solo login y password desde el JSON
		OrganizadorDeEventos org = new OrganizadorDeEventos(login, password);
		
		org.setAdmin(admin);
		org.setMapa_eventos(admin.mapa_eventos);
		org.setMapa_venues(admin.mapa_venues);
		
		resultado.add(org);
		}
		}
		
		return resultado;
	}
    public static void guardarOrganizadores(String rutaOrganizadores,
            List<OrganizadorDeEventos> organizadores) throws IOException {
			JsonArray arr = new JsonArray();
			
			for (OrganizadorDeEventos org : organizadores) {
			JsonObject o = new JsonObject();
			o.addProperty("login", org.getLogin());
			o.addProperty("password", org.getPassword());
			arr.add(o);
			}
			
			try (FileWriter writer = new FileWriter(rutaOrganizadores)) {
			gson.toJson(arr, writer);
			}
		}
}

