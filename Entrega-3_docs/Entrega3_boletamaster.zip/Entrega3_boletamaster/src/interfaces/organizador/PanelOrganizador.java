package interfaces.organizador;

import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.util.HashMap;

import modelo.OrganizadorDeEventos;
import modelo.Evento;
import modelo.Venue;

public class PanelOrganizador extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final Color FONDO = new Color(9, 33, 77);
    private static final Color BOTON = new Color(255, 204, 102);

    private final OrganizadorDeEventos organizador;

    private JPanel panelCrearEvento;
    private JPanel panelCancelarEvento;

    // Para panel de cancelación
    private DefaultListModel<String> modeloEventosCancelacion;
    private JList<String> listaEventosCancelacion;
    private JTextArea txtMotivoCancelacion;

    public PanelOrganizador(OrganizadorDeEventos organizador) {
        this.organizador = organizador;

        setBackground(FONDO);
        setLayout(null);

        JLabel lblTitulo = new JLabel("Panel del Organizador");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 25));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(150, 10, 400, 40);
        add(lblTitulo);

        // -------- Botones laterales --------
        JButton btnCrearEvento = new JButton("Crear evento");
        btnCrearEvento.setFont(new Font("Arial", Font.PLAIN, 13));
        btnCrearEvento.setBounds(30, 70, 180, 40);
        btnCrearEvento.setBackground(BOTON);
        add(btnCrearEvento);

        JButton btnSolicitudCancelacion = new JButton("Solicitar cancelación");
        btnSolicitudCancelacion.setFont(new Font("Arial", Font.PLAIN, 13));
        btnSolicitudCancelacion.setBounds(30, 120, 180, 40);
        btnSolicitudCancelacion.setBackground(BOTON);
        add(btnSolicitudCancelacion);

        // -------- Paneles derechos --------
        panelCrearEvento = crearPanelCrearEvento();
        panelCrearEvento.setBounds(230, 70, 430, 320);
        add(panelCrearEvento);

        panelCancelarEvento = crearPanelCancelarEvento();
        panelCancelarEvento.setBounds(230, 70, 430, 320);
        add(panelCancelarEvento);

        mostrarSolo(panelCrearEvento);

        // Solo cambian el panel visible
        btnCrearEvento.addActionListener(e -> mostrarSolo(panelCrearEvento));
        btnSolicitudCancelacion.addActionListener(e -> {
            recargarListaEventosCancelacion();
            mostrarSolo(panelCancelarEvento);
        });
    }

    private void mostrarSolo(JPanel panel) {
        panelCrearEvento.setVisible(panel == panelCrearEvento);
        panelCancelarEvento.setVisible(panel == panelCancelarEvento);
    }

    // =====================================================================
    // 1. CREAR EVENTO
    //    Usa: organizador.crear_evento(id, fecha, tipoEvento, estadoEvento, nombre_venue)
    // =====================================================================
    private JPanel crearPanelCrearEvento() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lblTitulo = new JLabel("Crear nuevo evento");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.PLAIN, 18));
        lblTitulo.setBounds(10, 10, 250, 30);
        panel.add(lblTitulo);

        JLabel lblNombre = new JLabel("Nombre / ID evento:");
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setBounds(10, 60, 150, 25);
        panel.add(lblNombre);

        JTextField txtNombre = new JTextField();
        txtNombre.setBounds(170, 60, 220, 25);
        panel.add(txtNombre);

        JLabel lblFecha = new JLabel("Fecha (día/mes/año):");
        lblFecha.setForeground(Color.WHITE);
        lblFecha.setBounds(10, 100, 150, 25);
        panel.add(lblFecha);

        // Usamos un JSpinner de tipo Date
        SpinnerDateModel dateModel = new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner spFecha = new JSpinner(dateModel);
        JSpinner.DateEditor editorFecha = new JSpinner.DateEditor(spFecha, "dd/MM/yyyy HH:mm");
        spFecha.setEditor(editorFecha);
        spFecha.setBounds(170, 100, 220, 25);
        panel.add(spFecha);

        JLabel lblTipo = new JLabel("Tipo de evento:");
        lblTipo.setForeground(Color.WHITE);
        lblTipo.setBounds(10, 140, 150, 25);
        panel.add(lblTipo);

        JComboBox<String> cbTipo = new JComboBox<>(new String[]{
                "Concierto", "Teatro", "Deportivo", "Festival", "Otro"
        });
        cbTipo.setBounds(170, 140, 220, 25);
        panel.add(cbTipo);

        JLabel lblVenue = new JLabel("Venue:");
        lblVenue.setForeground(Color.WHITE);
        lblVenue.setBounds(10, 180, 150, 25);
        panel.add(lblVenue);

        // Cargar nombres de venues desde el organizador
        JComboBox<String> cbVenue = new JComboBox<>();
        cbVenue.setBounds(170, 180, 220, 25);
        panel.add(cbVenue);
        recargarVenuesEnCombo(cbVenue);

        JButton btnCrear = new JButton("Crear evento");
        btnCrear.setBounds(10, 230, 150, 30);
        btnCrear.setBackground(BOTON);
        panel.add(btnCrear);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 270, 400, 30);
        panel.add(lblMensaje);

        btnCrear.addActionListener(e -> {
            String nombreEvento = txtNombre.getText().trim();
            Date fecha = (Date) spFecha.getValue();
            String tipoEvento = (String) cbTipo.getSelectedItem();
            String nombreVenue = (String) cbVenue.getSelectedItem();

            if (nombreEvento.isEmpty() || nombreVenue == null) {
                lblMensaje.setText("Debe ingresar nombre del evento y seleccionar un venue.");
                return;
            }

            String estadoEvento = "PROGRAMADO";

            try {
                organizador.crear_evento(nombreEvento, fecha, tipoEvento, estadoEvento, nombreVenue);

                lblMensaje.setText("Evento '" + nombreEvento + "' creado correctamente.");
            } catch (Exception ex) {
                lblMensaje.setText("Error al crear evento: " + ex.getMessage());
            }
        });

        return panel;
    }

    private void recargarVenuesEnCombo(JComboBox<String> cbVenue) {
        cbVenue.removeAllItems();

        HashMap<String, Venue> mapaVenues = organizador.getMapa_venues();

        if (mapaVenues != null && !mapaVenues.isEmpty()) {
            for (String nombre : mapaVenues.keySet()) {
                cbVenue.addItem(nombre);
            }
        }
    }

    // =====================================================================
    // 2. SOLICITUD DE CANCELACIÓN DE EVENTO
    //    Usa: organizador.sugerir_cancelar_evento(nombre_evento, solicitud)
    // =====================================================================
    private JPanel crearPanelCancelarEvento() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lbl = new JLabel("Solicitar cancelación de evento");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 18));
        lbl.setBounds(10, 10, 350, 30);
        panel.add(lbl);

        JLabel lblEventos = new JLabel("Eventos creados:");
        lblEventos.setForeground(Color.WHITE);
        lblEventos.setBounds(10, 50, 150, 25);
        panel.add(lblEventos);

        modeloEventosCancelacion = new DefaultListModel<>();
        listaEventosCancelacion = new JList<>(modeloEventosCancelacion);
        listaEventosCancelacion.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollEventos = new JScrollPane(listaEventosCancelacion);
        scrollEventos.setBounds(10, 80, 180, 180);
        panel.add(scrollEventos);

        JLabel lblMotivo = new JLabel("Motivo de la cancelación:");
        lblMotivo.setForeground(Color.WHITE);
        lblMotivo.setBounds(210, 50, 200, 25);
        panel.add(lblMotivo);

        txtMotivoCancelacion = new JTextArea();
        txtMotivoCancelacion.setLineWrap(true);
        txtMotivoCancelacion.setWrapStyleWord(true);
        JScrollPane scrollMotivo = new JScrollPane(txtMotivoCancelacion);
        scrollMotivo.setBounds(210, 80, 200, 180);
        panel.add(scrollMotivo);

        JButton btnEnviarSolicitud = new JButton("Enviar solicitud");
        btnEnviarSolicitud.setBounds(10, 270, 150, 30);
        btnEnviarSolicitud.setBackground(BOTON);
        panel.add(btnEnviarSolicitud);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 305, 400, 20);
        panel.add(lblMensaje);

        btnEnviarSolicitud.addActionListener(e -> {
            String nombreEvento = listaEventosCancelacion.getSelectedValue();
            String motivo = txtMotivoCancelacion.getText().trim();

            if (nombreEvento == null) {
                lblMensaje.setText("Selecciona un evento.");
                return;
            }
            if (motivo.isEmpty()) {
                lblMensaje.setText("Escribe un motivo para la cancelación.");
                return;
            }

            try {
                organizador.sugerir_cancelar_evento(nombreEvento, motivo);
                lblMensaje.setText("Solicitud enviada para '" + nombreEvento + "'.");
                txtMotivoCancelacion.setText("");
            } catch (Exception ex) {
                lblMensaje.setText("Error al enviar solicitud: " + ex.getMessage());
            }
        });

        return panel;
    }

    private void recargarListaEventosCancelacion() {
        if (modeloEventosCancelacion == null) return;

        modeloEventosCancelacion.clear();

        // Suponemos que OrganizadorDeEventos tiene:
        // public HashMap<String, Evento> getEventos()
        HashMap<String, Evento> mapaEventos = organizador.getEventos();
        if (mapaEventos != null && !mapaEventos.isEmpty()) {
            for (String nombre : mapaEventos.keySet()) {
                modeloEventosCancelacion.addElement(nombre);
            }
        }
    }
}
