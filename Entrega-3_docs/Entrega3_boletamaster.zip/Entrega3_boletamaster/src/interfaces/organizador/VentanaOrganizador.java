package interfaces.organizador;

import javax.swing.*;
import java.awt.*;
import modelo.OrganizadorDeEventos;

public class VentanaOrganizador extends JFrame {

    private static final long serialVersionUID = 1L;

    public VentanaOrganizador(OrganizadorDeEventos organizador) {
        setTitle("BoletaMaster - Organizador: " + organizador.getLogin());
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        add(new PanelOrganizador(organizador), BorderLayout.CENTER);
    }
}
