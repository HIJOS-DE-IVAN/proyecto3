package interfaces;

import modelo.Administrador;
import modelo.Cliente;
import modelo.OrganizadorDeEventos;

import javax.swing.*;

import Persistencia.PersistenciaInterfaz;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class VentanaRegistro extends JFrame {

    private static final long serialVersionUID = 1L;

    // Colores
    private static final Color COLOR_FONDO_OSCURO = new Color(9, 33, 77);
    private static final Color COLOR_ACENTO       = new Color(255, 215, 0);
    private static final Color COLOR_FONDO_CLARO  = new Color(245, 247, 250);

    private static final String RUTA_CLIENTES      = "datos/clientes.json";
    private static final String RUTA_ORGANIZADORES = "datos/organizadores.json";
    private static final String RUTA_ADMIN         = "datos/admin.json";

    // Referencias a los datos en memoria
    private final List<Cliente> clientes;
    private final List<OrganizadorDeEventos> organizadores;
    private final Administrador adminPrincipal;

    // Componentes
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JPasswordField txtPassword2;
    private JLabel lblError;

    private JRadioButton rbCliente;
    private JRadioButton rbOrganizador;

    public VentanaRegistro(List<Cliente> clientes,
                           List<OrganizadorDeEventos> organizadores,
                           Administrador adminPrincipal) {
        this.clientes = (clientes != null) ? clientes : new ArrayList<>();
        this.organizadores = (organizadores != null) ? organizadores : new ArrayList<>();
        this.adminPrincipal = adminPrincipal;

        setTitle("BoletaMaster - Registro");
        setSize(650, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        initUI();
    }

    private void initUI() {
        getContentPane().setLayout(new BorderLayout());

        // Panel izquierdo (branding)
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setBackground(COLOR_FONDO_OSCURO);
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        JLabel lblTituloApp = new JLabel("BoletaMaster");
        lblTituloApp.setForeground(Color.WHITE);
        lblTituloApp.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblTituloApp.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSubtitulo = new JLabel("<html>Crea tu cuenta<br>como cliente u organizador<br>y gestiona tus eventos.</html>");
        lblSubtitulo.setForeground(Color.LIGHT_GRAY);
        lblSubtitulo.setFont(new Font("SansSerif", Font.PLAIN, 16));
        lblSubtitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        lblSubtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel barraAmarilla = new JPanel();
        barraAmarilla.setBackground(COLOR_ACENTO);
        barraAmarilla.setMaximumSize(new Dimension(80, 4));
        barraAmarilla.setPreferredSize(new Dimension(80, 4));
        barraAmarilla.setAlignmentX(Component.LEFT_ALIGNMENT);
        barraAmarilla.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        panelIzquierdo.add(lblTituloApp);
        panelIzquierdo.add(barraAmarilla);
        panelIzquierdo.add(lblSubtitulo);
        panelIzquierdo.add(Box.createVerticalGlue());

        getContentPane().add(panelIzquierdo, BorderLayout.WEST);
        panelIzquierdo.setPreferredSize(new Dimension(260, getHeight()));

        // Panel derecho (formulario)
        JPanel panelDerecho = new JPanel(new GridBagLayout());
        panelDerecho.setBackground(COLOR_FONDO_CLARO);
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1;

        int fila = 0;

        JLabel lblTitulo = new JLabel("Crear cuenta");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(30, 30, 30));
        gbc.gridy = fila++;
        panelDerecho.add(lblTitulo, gbc);

        JLabel lblDesc = new JLabel("Selecciona el tipo de cuenta e ingresa tus datos");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblDesc.setForeground(new Color(100, 100, 100));
        gbc.gridy = fila++;
        panelDerecho.add(lblDesc, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(Box.createVerticalStrut(10), gbc);

        // Tipo de cuenta (cliente / organizador)
        JPanel panelTipo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelTipo.setOpaque(false);
        rbCliente = new JRadioButton("Cliente");
        rbOrganizador = new JRadioButton("Organizador de eventos");
        rbCliente.setOpaque(false);
        rbOrganizador.setOpaque(false);
        rbCliente.setSelected(true);

        ButtonGroup grupoTipo = new ButtonGroup();
        grupoTipo.add(rbCliente);
        grupoTipo.add(rbOrganizador);

        panelTipo.add(rbCliente);
        panelTipo.add(rbOrganizador);

        gbc.gridy = fila++;
        panelDerecho.add(panelTipo, gbc);

        // Usuario
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panelDerecho.add(lblUsuario, gbc);

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        gbc.gridy = fila++;
        panelDerecho.add(txtUsuario, gbc);

        // Contraseña
        JLabel lblPass1 = new JLabel("Contraseña");
        lblPass1.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panelDerecho.add(lblPass1, gbc);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        gbc.gridy = fila++;
        panelDerecho.add(txtPassword, gbc);

        // Confirmar contraseña
        JLabel lblPass2 = new JLabel("Confirmar contraseña");
        lblPass2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panelDerecho.add(lblPass2, gbc);

        txtPassword2 = new JPasswordField();
        txtPassword2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtPassword2.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        gbc.gridy = fila++;
        panelDerecho.add(txtPassword2, gbc);

        // Error
        lblError = new JLabel(" ");
        lblError.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblError.setForeground(Color.RED);
        gbc.gridy = fila++;
        panelDerecho.add(lblError, gbc);

        // Botón Registrar
        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setBackground(COLOR_FONDO_OSCURO);
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gbc.gridy = fila++;
        panelDerecho.add(btnRegistrar, gbc);

        // Botón Cancelar
        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btnCancelar.setFocusPainted(false);
        btnCancelar.setContentAreaFilled(false);
        btnCancelar.setBorder(null);
        btnCancelar.setForeground(new Color(80, 80, 150));
        gbc.gridy = fila++;
        gbc.anchor = GridBagConstraints.CENTER;
        panelDerecho.add(btnCancelar, gbc);

        getContentPane().add(panelDerecho, BorderLayout.CENTER);

        // Listeners
        btnRegistrar.addActionListener(e -> registrarUsuario());
        btnCancelar.addActionListener(e -> {
            dispose();
            VentanaPrincipal vp = new VentanaPrincipal();
            vp.setVisible(true);
        });
    }

    private void registrarUsuario() {
        limpiarError();

        String login = txtUsuario.getText().trim();
        String pass1 = new String(txtPassword.getPassword()).trim();
        String pass2 = new String(txtPassword2.getPassword()).trim();

        if (login.isEmpty() || pass1.isEmpty() || pass2.isEmpty()) {
            mostrarError("Todos los campos son obligatorios.");
            return;
        }

        if (!pass1.equals(pass2)) {
            mostrarError("Las contraseñas no coinciden.");
            return;
        }

        // Validar que el login no exista ni en clientes ni en organizadores
        for (Cliente c : clientes) {
            if (c.getLogin().equals(login)) {
                mostrarError("Ya existe un cliente con ese usuario.");
                return;
            }
        }
        for (OrganizadorDeEventos o : organizadores) {
            if (o.getLogin().equals(login)) {
                mostrarError("Ya existe un organizador con ese usuario.");
                return;
            }
        }

        if (rbCliente.isSelected()) {
            registrarComoCliente(login, pass1);
        } else if (rbOrganizador.isSelected()) {
            registrarComoOrganizador(login, pass1);
        } else {
            mostrarError("Selecciona un tipo de cuenta.");
        }
    }

    private void registrarComoCliente(String login, String pass) {
        Cliente nuevo = new Cliente(login, pass, 0.0);
        nuevo.setSaldoPlataforma(0.0);
        if (nuevo.getTiquetes() == null) {
            nuevo.setTiquetes(new ArrayList<>());
        }

        clientes.add(nuevo);

        // Opcional: mantener coherente el mapa_clientes del admin en memoria
        if (adminPrincipal != null) {
            if (adminPrincipal.mapa_clientes == null) {
                adminPrincipal.mapa_clientes = new java.util.HashMap<>();
            }
            adminPrincipal.mapa_clientes.put(nuevo.getLogin(), nuevo);
        }

        //Persistencia de mrd.
        try {
            PersistenciaInterfaz.guardarClientes(RUTA_CLIENTES, clientes);
            if (adminPrincipal != null) {
                PersistenciaInterfaz.guardarAdministrador(RUTA_ADMIN, adminPrincipal);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            mostrarError("Error guardando el cliente: " + ex.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Cliente registrado correctamente. Ahora puedes iniciar sesión.",
                "Registro exitoso",
                JOptionPane.INFORMATION_MESSAGE);

        dispose();
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);
    }

    private void registrarComoOrganizador(String login, String pass) {
        // Crear organizador solo con login/pass
        OrganizadorDeEventos nuevo = new OrganizadorDeEventos(login, pass);

        // Setear admin y mapas en memoria
        if (adminPrincipal != null) {
            nuevo.setAdmin(adminPrincipal);
            nuevo.setMapa_eventos(adminPrincipal.mapa_eventos);
            nuevo.setMapa_venues(adminPrincipal.mapa_venues);
        }

        organizadores.add(nuevo);

        // Guardar en JSON solo login/password
        try {
            PersistenciaInterfaz.guardarOrganizadores(RUTA_ORGANIZADORES, organizadores);
        } catch (IOException ex) {
            ex.printStackTrace();
            mostrarError("Error guardando el organizador: " + ex.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Organizador registrado correctamente. Ahora puedes iniciar sesión.",
                "Registro exitoso",
                JOptionPane.INFORMATION_MESSAGE);

        dispose();
        VentanaPrincipal vp = new VentanaPrincipal();
        vp.setVisible(true);
    }

    private void mostrarError(String mensaje) {
        lblError.setText(mensaje);
    }

    private void limpiarError() {
        lblError.setText(" ");
    }
}
