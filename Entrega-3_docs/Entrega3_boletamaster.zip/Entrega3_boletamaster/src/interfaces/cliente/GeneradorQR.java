package interfaces.cliente;

import com.google.zxing.*;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import java.io.File;
import java.nio.file.Path;

public class GeneradorQR {

    public static File generarQR(String texto, String nombreArchivo) {
        try {
            int ancho = 300;
            int alto = 300;

            BitMatrix matriz = new MultiFormatWriter().encode(
                    texto,
                    BarcodeFormat.QR_CODE,
                    ancho,
                    alto
            );

            File archivo = new File(nombreArchivo);
            Path ruta = archivo.toPath();
            MatrixToImageWriter.writeToPath(matriz, "png", ruta);

            return archivo;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
