package interfaces.cliente;

import modelo.Cliente;
import modelo.Tiquete;
import modelo.Localidad;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PanelMisTiquetes extends JPanel {

    public interface ListenerDetalleTiquete {
        void onVerDetalle(Tiquete tiquete);
    }

    private static final Color FONDO_PANEL = new Color(18, 45, 94);

    private final Cliente cliente;
    private final ListenerDetalleTiquete listener;

    private final List<Tiquete> tiquetesCliente;  // lista interna manejada por el panel
    private JTable tabla;
    private DefaultTableModel modelo;

    public PanelMisTiquetes(Cliente cliente,
                            List<Tiquete> ignorado,
                            ListenerDetalleTiquete listener) {
        this.cliente = cliente;
        this.listener = listener;
        this.tiquetesCliente = new ArrayList<>();

        initUI();
        recargarTabla();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(FONDO_PANEL);

        JLabel lblTitulo = new JLabel("Mis tiquetes");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        add(lblTitulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new String[]{"ID", "Fecha", "Hora", "Precio", "Transferible", "Vendido"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);

        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll, BorderLayout.CENTER);

        JButton btnVerDetalle = new JButton("Ver detalle");
        btnVerDetalle.setFocusPainted(false);
        btnVerDetalle.setBackground(new Color(255, 140, 0));
        btnVerDetalle.setForeground(Color.WHITE);
        btnVerDetalle.setFont(new Font("Arial", Font.BOLD, 14));
        btnVerDetalle.addActionListener(e -> verDetalleSeleccionado());

        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBoton.setBackground(FONDO_PANEL);
        panelBoton.add(btnVerDetalle);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void recargarTabla() {
        // Limpiar modelo y lista interna
        modelo.setRowCount(0);
        tiquetesCliente.clear();

        if (cliente.getTiquetes() == null) {
            return;
        }

        tiquetesCliente.addAll(cliente.getTiquetes());

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        for (Tiquete t : tiquetesCliente) {
            String fechaStr = (t.getFecha() != null) ? sdf.format(t.getFecha()) : "-";
            String horaStr = (t.getHora() < 0) ? "-" : String.valueOf(t.getHora());

            Localidad loc = t.getLocalidad();
            String nombreLocalidad = (loc != null) ? loc.getNombre() : "-";

            modelo.addRow(new Object[]{
                    t.getIdentificador(),
                    fechaStr,
                    horaStr,
                    nombreLocalidad,
                    t.getPrecio(),
                    t.isEsTransferible() ? "Sí" : "No",
                    t.isEstaVendido() ? "Sí" : "No"
            });
        }
    }

    private void verDetalleSeleccionado() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this,
                    "Selecciona un tiquete de la tabla.",
                    "Información",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (fila >= tiquetesCliente.size()) {
            JOptionPane.showMessageDialog(this,
                    "Error interno: índice fuera de rango.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        Tiquete seleccionado = tiquetesCliente.get(fila);
        if (listener != null) {
            listener.onVerDetalle(seleccionado);
        }
    }
}
