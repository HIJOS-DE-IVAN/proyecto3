package interfaces.cliente;

import modelo.Administrador;
import modelo.Cliente;
import modelo.Evento;
import modelo.Localidad;
import modelo.Tiquete;
import modelo.Venue;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PanelDetalleTiquete extends JPanel {

    private static final Color FONDO_EXTERIOR = new Color(9, 33, 77); // azul oscuro
    private static final Color FONDO_TICKET   = Color.WHITE;
    private static final Color BORDE          = new Color(200, 200, 200);

    private final Tiquete tiquete;
    private final Administrador admin;

    private Evento evento;
    private Venue venue;
    private Localidad localidad;


    public PanelDetalleTiquete(Tiquete tiquete, Administrador admin) {
        this.tiquete = tiquete;
        this.admin = admin;

        localizarEventoYVenue();
        initUI();
    }

    private void localizarEventoYVenue() {
        if (admin == null) {
            System.out.println("   admin es null");
            return;
        }
        if (admin.mapa_localidades == null || admin.mapa_localidades.isEmpty()) {
            System.out.println("   mapa_localidades vacío");
            return;
        }

        String idLocalidadEncontrada = null;

        for (Localidad loc : admin.mapa_localidades.values()) {
            if (loc.getTiquetes() == null) continue;

            for (Tiquete t : loc.getTiquetes()) {
                if (t != null &&
                    t.getIdentificador() != null &&
                    t.getIdentificador().equals(tiquete.getIdentificador())) {

                    this.localidad = loc;
                    idLocalidadEncontrada = loc.getId();
                    break;
                }
            }
            if (idLocalidadEncontrada != null) break;
        }

        if (idLocalidadEncontrada == null) {
            System.out.println("   No se encontró localidad para el tiquete");
            return;
        }

        if (tiquete.getLocalidad() == null && this.localidad != null) {
            tiquete.setLocalidad(this.localidad);
        }

        String idVenueEncontrado = null;
        if (admin.mapa_venues != null) {
            for (Venue v : admin.mapa_venues.values()) {
                if (v.getLocalidades() == null) continue;

                for (Localidad loc : v.getLocalidades()) {
                    if (loc != null && loc.getId().equals(idLocalidadEncontrada)) {

                        this.venue = v;
                        idVenueEncontrado = v.getId();
                        break;
                    }
                }
                if (idVenueEncontrado != null) break;
            }
        }

        if (idVenueEncontrado == null) {
            System.out.println("   No se encontró venue para la localidad " + idLocalidadEncontrada);
            return;
        }

        if (admin.mapa_eventos != null) {
            for (Evento ev : admin.mapa_eventos.values()) {
                if (ev.getVenues() == null) continue;

                for (Venue vEv : ev.getVenues()) {
                    if (vEv != null && vEv.getId().equals(idVenueEncontrado)) {

                        this.evento = ev;

                        break;
                    }
                }
                if (this.evento != null) break;
            }
        }

        if (evento == null) {
            System.out.println("   No se encontró evento para el venue " + idVenueEncontrado);
        }
    }

    private void initUI() {
        setBackground(FONDO_EXTERIOR);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel contenedor = new JPanel();
        contenedor.setBackground(FONDO_TICKET);
        contenedor.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDE, 2),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        contenedor.setLayout(new BorderLayout(20, 0));

        JPanel panelInfo = new JPanel();
        panelInfo.setBackground(FONDO_TICKET);
        panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS));

        SimpleDateFormat sdfFecha = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfFechaHora = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        Localidad loc = (this.localidad != null) ? this.localidad : tiquete.getLocalidad();
        String nombreLocalidad = (loc != null) ? loc.getNombre() : "-";

        String nombreEvento;
        if (evento != null) {
            nombreEvento = evento.getTipoEvento() + " (" + evento.getId() + ")";
        } else {
            nombreEvento = "Evento - Localidad " + nombreLocalidad;
        }
        
        String nombreVenue;
        if (venue != null) {
            nombreVenue = venue.getNombre() + " - " + venue.getUbicacion();
        } else {
            nombreVenue = "Venue asociado a " + nombreLocalidad;
        }

        String fechaEventoStr;
        if (evento != null && evento.getFecha() != null) {
            fechaEventoStr = sdfFecha.format(evento.getFecha());
        } else if (tiquete.getFecha() != null) {
            fechaEventoStr = sdfFecha.format(tiquete.getFecha());
        } else {
            fechaEventoStr = "-";
        }
        
        String fechaImpresionStr = sdfFechaHora.format(new Date());

        JLabel lblTituloEvento = new JLabel(nombreEvento);
        lblTituloEvento.setFont(new Font("Arial", Font.BOLD, 20));

        JLabel lblVenue = new JLabel("Lugar: " + nombreVenue);
        lblVenue.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel lblLocalidad = new JLabel("Localidad: " + nombreLocalidad);
        lblLocalidad.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel lblId = new JLabel("ID tiquete: " + tiquete.getIdentificador());
        lblId.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel lblFechaEvento = new JLabel("Fecha del evento: " + fechaEventoStr);
        lblFechaEvento.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel lblHora = new JLabel("Hora: " + tiquete.getHora() + ":00");
        lblHora.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel lblPrecio = new JLabel(String.format("Precio pagado: $%,.2f", tiquete.getPrecio()));
        lblPrecio.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel lblFechaImpresion = new JLabel("Fecha de impresión: " + fechaImpresionStr);
        lblFechaImpresion.setFont(new Font("Arial", Font.ITALIC, 12));
        lblFechaImpresion.setForeground(Color.DARK_GRAY);

        panelInfo.add(lblTituloEvento);
        panelInfo.add(Box.createVerticalStrut(5));
        panelInfo.add(lblVenue);
        panelInfo.add(lblLocalidad);
        panelInfo.add(Box.createVerticalStrut(10));
        panelInfo.add(lblId);
        panelInfo.add(lblFechaEvento);
        panelInfo.add(lblHora);
        panelInfo.add(Box.createVerticalStrut(10));
        panelInfo.add(lblPrecio);
        panelInfo.add(Box.createVerticalGlue());
        panelInfo.add(lblFechaImpresion);

        JPanel panelQR = new JPanel(new BorderLayout());
        panelQR.setBackground(FONDO_TICKET);

        JLabel lblQR = new JLabel();
        lblQR.setHorizontalAlignment(SwingConstants.CENTER);

        BufferedImage imgQR = generarQR();
        if (imgQR != null) {
            lblQR.setIcon(new ImageIcon(imgQR));
        } else {
            lblQR.setText("No se pudo generar el QR");
            lblQR.setForeground(Color.WHITE);
        }

        panelQR.add(lblQR, BorderLayout.CENTER);

        contenedor.add(panelInfo, BorderLayout.CENTER);
        contenedor.add(panelQR, BorderLayout.EAST);

        add(contenedor, BorderLayout.CENTER);

    }

    /**
     * Genera el QR usando información real del tiquete + evento si se encontró.
     */
    private BufferedImage generarQR() {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("ID=").append(tiquete.getIdentificador()).append(";");

            if (evento != null) {
                sb.append("EVENTO=").append(evento.getTipoEvento()).append(";");
                sb.append("EVENTO_ID=").append(evento.getId()).append(";");
            }
            if (tiquete.getFecha() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                sb.append("FECHA_EVENTO=").append(sdf.format(tiquete.getFecha())).append(";");
            }
            sb.append("HORA=").append(tiquete.getHora()).append(";");

            Localidad loc = (this.localidad != null) ? this.localidad : tiquete.getLocalidad();
            if (loc != null) {
                sb.append("LOCALIDAD=").append(loc.getNombre()).append(";");
            }

            sb.append("PRECIO=").append(tiquete.getPrecio()).append(";");

            String data = sb.toString();

            int size = 200;
            BitMatrix matrix = new MultiFormatWriter()
                    .encode(data, BarcodeFormat.QR_CODE, size, size);

            return MatrixToImageWriter.toBufferedImage(matrix);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }
}
