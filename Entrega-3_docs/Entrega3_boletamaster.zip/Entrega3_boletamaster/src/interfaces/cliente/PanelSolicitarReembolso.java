package interfaces.cliente;

import modelo.Administrador;
import modelo.Cliente;
import modelo.Tiquete;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PanelSolicitarReembolso extends JPanel {

    private static final Color FONDO_PANEL = new Color(18, 45, 94);
    private static final Color NARANJA     = new Color(255, 140, 0);

    private final Cliente cliente;
    private final Administrador admin;

    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextArea txtMotivo;

    private List<Tiquete> tiquetesVendidos;

    public PanelSolicitarReembolso(Cliente cliente, Administrador admin) {
        this.cliente = cliente;
        this.admin = admin;
        initUI();
    }

    public void refrescarDatos() {
        cargarTiquetesVendidos();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(FONDO_PANEL);

        JLabel lblTitulo = new JLabel("Solicitar reembolso");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        add(lblTitulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new String[]{"ID", "Fecha", "Hora", "Precio"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(24);

        JScrollPane scrollTabla = new JScrollPane(tabla);
        add(scrollTabla, BorderLayout.CENTER);

        // Panel inferior: motivo + botón
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBackground(FONDO_PANEL);
        panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtMotivo = new JTextArea(3, 40);
        txtMotivo.setLineWrap(true);
        txtMotivo.setWrapStyleWord(true);

        JScrollPane scrollMotivo = new JScrollPane(txtMotivo);
        scrollMotivo.setBorder(BorderFactory.createTitledBorder("Motivo del reembolso"));

        JButton btnSolicitar = new JButton("Enviar solicitud");
        btnSolicitar.setBackground(NARANJA);
        btnSolicitar.setForeground(Color.WHITE);
        btnSolicitar.setFocusPainted(false);
        btnSolicitar.setFont(new Font("Arial", Font.BOLD, 14));
        btnSolicitar.addActionListener(e -> solicitarReembolso());

        panelInferior.add(scrollMotivo, BorderLayout.CENTER);

        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBoton.setBackground(FONDO_PANEL);
        panelBoton.add(btnSolicitar);

        panelInferior.add(panelBoton, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);

        // Cargar datos iniciales
        cargarTiquetesVendidos();
    }

    private void cargarTiquetesVendidos() {
        modelo.setRowCount(0);
        tiquetesVendidos = new ArrayList<>();

        if (cliente.getTiquetes() == null) return;

        for (Tiquete t : cliente.getTiquetes()) {
            if (t.isEstaVendido()) {
                tiquetesVendidos.add(t);
                modelo.addRow(new Object[]{
                        t.getIdentificador(),
                        t.getFecha(),
                        t.getHora(),
                        t.getPrecio()
                });
            }
        }
    }

    private void solicitarReembolso() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this,
                    "Selecciona un tiquete de la tabla.",
                    "Información",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String motivo = txtMotivo.getText().trim();
        if (motivo.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Escribe un motivo para el reembolso.",
                    "Información",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (admin == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay administrador cargado para registrar la solicitud.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        Tiquete t = tiquetesVendidos.get(fila);

        if (admin.mapa_solicitudes == null) {
            admin.mapa_solicitudes = new java.util.HashMap<>();
        }

        String clave = "Reembolso: " + t.getIdentificador();
        admin.mapa_solicitudes.put(clave, motivo);

        JOptionPane.showMessageDialog(this,
                "Solicitud de reembolso enviada.\nID tiquete: " + t.getIdentificador(),
                "Solicitud enviada",
                JOptionPane.INFORMATION_MESSAGE);

        txtMotivo.setText("");
    }
}
