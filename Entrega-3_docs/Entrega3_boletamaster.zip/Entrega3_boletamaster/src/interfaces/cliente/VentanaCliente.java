package interfaces.cliente;

import modelo.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import Persistencia.PersistenciaInterfaz;

public class VentanaCliente extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final Color FONDO = new Color(9, 33, 77);
    private static final Color FONDO_PANEL = new Color(18, 45, 94);
    private static final Color NARANJA = new Color(255, 140, 0);

    private static final String RUTA_ADMIN    = "datos/admin.json";
    private static final String RUTA_CLIENTES = "datos/clientes.json";

    private final Cliente cliente;
    private final List<Tiquete> tiquetesCliente;

    private JPanel panelCentral;
    private CardLayout cardLayout;
    private PanelMisTiquetes panelMisTiquetes;
    private PanelComprarTiquete panelComprarTiquete;
    private PanelSolicitarReembolso panelSolicitarReembolso;

    private Administrador admin;

    public VentanaCliente(Cliente cliente, Administrador admin) {
        this.cliente = cliente;
        this.tiquetesCliente = cliente.getTiquetes();
        this.admin = admin;

        setTitle("BoletaMaster - Cliente: " + cliente.getLogin());
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();
    }

    private void initUI() {

        setLayout(new BorderLayout());

        // ---------- Panel lateral (menú) ----------
        JPanel panelLateral = new JPanel();
        panelLateral.setBackground(FONDO);
        panelLateral.setLayout(new BoxLayout(panelLateral, BoxLayout.Y_AXIS));
        panelLateral.setPreferredSize(new Dimension(230, 0));

        JLabel lblTitulo = new JLabel("BoletaMaster");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JLabel lblUsuario = new JLabel("👤 " + cliente.getLogin());
        lblUsuario.setForeground(Color.LIGHT_GRAY);
        lblUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelLateral.add(lblTitulo);
        panelLateral.add(lblUsuario);
        panelLateral.add(Box.createVerticalStrut(30));

        JButton btnMisTiquetes = crearBotonMenu("Mis tiquetes");
        JButton btnComprar = crearBotonMenu("Comprar tiquetes");
        JButton btnReembolso = crearBotonMenu("Solicitar reembolso");
        JButton btnSalir = crearBotonMenu("Cerrar sesión");

        panelLateral.add(btnMisTiquetes);
        panelLateral.add(Box.createVerticalStrut(10));
        panelLateral.add(btnComprar);
        panelLateral.add(Box.createVerticalStrut(10));
        panelLateral.add(btnReembolso);
        panelLateral.add(Box.createVerticalGlue());
        panelLateral.add(btnSalir);
        panelLateral.add(Box.createVerticalStrut(15));

        // ---------- Panel central con CardLayout ----------
        cardLayout = new CardLayout();
        panelCentral = new JPanel(cardLayout);
        panelCentral.setBackground(FONDO_PANEL);

        // Pestaña: Mis tiquetes
        panelMisTiquetes = new PanelMisTiquetes(
                cliente,
                tiquetesCliente,
                tiqueteSeleccionado -> mostrarDetalleTiquete(tiqueteSeleccionado)
        );
        panelCentral.add(panelMisTiquetes, "MIS_TIQUETES");

        // Pestaña: Comprar
        panelComprarTiquete = new PanelComprarTiquete(cliente, admin);
        panelCentral.add(panelComprarTiquete, "COMPRAR");

        // Pestaña: Reembolso
        panelSolicitarReembolso = new PanelSolicitarReembolso(cliente, admin);
        panelCentral.add(panelSolicitarReembolso, "REEMBOLSO");

        // Listeners de menú
        btnMisTiquetes.addActionListener(e -> {
            panelMisTiquetes.recargarTabla();
            cardLayout.show(panelCentral, "MIS_TIQUETES");
        });

        btnComprar.addActionListener(e -> {
            panelComprarTiquete.refrescarDatos();
            cardLayout.show(panelCentral, "COMPRAR");
        });

        btnReembolso.addActionListener(e -> {
            panelSolicitarReembolso.refrescarDatos();
            cardLayout.show(panelCentral, "REEMBOLSO");
        });

        btnSalir.addActionListener(e -> {
            // guardarCambiosClienteYAdmin();
            dispose();
        });

        add(panelLateral, BorderLayout.WEST);
        add(panelCentral, BorderLayout.CENTER);

        cardLayout.show(panelCentral, "MIS_TIQUETES");
    }

    private JButton crearBotonMenu(String texto) {
        JButton btn = new JButton(texto);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setFocusPainted(false);
        btn.setBackground(NARANJA);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return btn;
    }

    private void mostrarDetalleTiquete(Tiquete tiquete) {
        JDialog dialog = new JDialog(this, "Detalle del tiquete", true);
        dialog.setSize(700, 500);
        dialog.setLocationRelativeTo(this);

        PanelDetalleTiquete panelDetalle = new PanelDetalleTiquete(
                tiquete,
                admin
        );

        dialog.add(panelDetalle);
        dialog.setVisible(true);
    }

    // ============================================================
    //  Persistencia =(((((((8
    // ============================================================

    private void guardarCambiosClienteYAdmin() {
        try {
            if (admin != null && admin.mapa_clientes != null) {
                List<Cliente> lista = new ArrayList<>(admin.mapa_clientes.values());
                PersistenciaInterfaz.guardarClientes(RUTA_CLIENTES, lista);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al guardar clientes: " + e.getMessage(),
                    "Error de Persistencia",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        try {
            if (admin != null) {
                PersistenciaInterfaz.guardarAdministrador(RUTA_ADMIN, admin);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al guardar administrador: " + e.getMessage(),
                    "Error de Persistencia",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
