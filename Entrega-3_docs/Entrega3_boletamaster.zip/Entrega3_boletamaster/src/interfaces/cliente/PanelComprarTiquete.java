package interfaces.cliente;

import modelo.Administrador;
import modelo.Cliente;
import modelo.Evento;
import modelo.Localidad;
import modelo.Tiquete;
import modelo.Venue;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PanelComprarTiquete extends JPanel {

    private static final Color FONDO_PANEL = new Color(18, 45, 94);
    private static final Color NARANJA     = new Color(255, 140, 0);

    private final Cliente cliente;
    private final Administrador admin;

    private JComboBox<Evento> comboEventos;
    private JComboBox<Venue> comboVenues;
    private JComboBox<Localidad> comboLocalidades;
    private JComboBox<Tiquete> comboTiquetes;
    private JLabel lblSaldo;
    private JLabel lblPrecioSeleccionado;


    public PanelComprarTiquete(Cliente cliente, Administrador admin) {
        this.cliente = cliente;
        this.admin = admin;
        initUI();
    }

    public void refrescarDatos() {
        cargarEventos();
        actualizarSaldo();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(FONDO_PANEL);

        JLabel lblTitulo = new JLabel("Comprar tiquetes");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridBagLayout());
        centro.setBackground(FONDO_PANEL);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        lblSaldo = new JLabel();
        lblSaldo.setForeground(Color.WHITE);
        lblSaldo.setFont(new Font("Arial", Font.BOLD, 14));
        actualizarSaldo();

        comboEventos = new JComboBox<>();
        comboVenues = new JComboBox<>();
        comboLocalidades = new JComboBox<>();
        comboTiquetes = new JComboBox<>();
        
        lblPrecioSeleccionado = new JLabel("Precio: -");
        lblPrecioSeleccionado.setForeground(Color.WHITE);
        lblPrecioSeleccionado.setFont(new Font("Arial", Font.BOLD, 14));

        // ==== RENDERERS PERSONALIZADOS ====

        // Eventos: "Concierto", "Festival de Comedia", etc.
        comboEventos.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Evento e) {
                    setText(e.getTipoEvento());
                } else if (value == null && index == -1) {
                    setText("Seleccione un evento");
                }

                return this;
            }
        });

        comboVenues.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Venue v) {
                    String ubic = (v.getUbicacion() != null) ? v.getUbicacion() : "";
                    setText(v.getNombre() + " - " + ubic);
                } else if (value == null && index == -1) {
                    setText("Seleccione un venue");
                }

                return this;
            }
        });

        comboLocalidades.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Localidad l) {
                    setText(l.getNombre());
                } else if (value == null && index == -1) {
                    setText("Seleccione una localidad");
                }

                return this;
            }
        });

        comboTiquetes.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Tiquete t) {
                    setText(t.getIdentificador() + " - $" + t.getPrecio());
                } else if (value == null && index == -1) {
                    setText("Seleccione un tiquete");
                }

                return this;
            }
        });

        // ==== LISTENERS ====
        comboEventos.addActionListener(e -> cargarVenues());
        comboVenues.addActionListener(e -> cargarLocalidades());
        comboLocalidades.addActionListener(e -> cargarTiquetesDisponibles());

        // Fila saldo
        gbc.gridwidth = 2;
        centro.add(lblSaldo, gbc);

        // Evento
        gbc.gridy++;
        gbc.gridwidth = 1;
        centro.add(crearLabel("Evento:"), gbc);
        gbc.gridx = 1;
        centro.add(comboEventos, gbc);

        // Venue
        gbc.gridy++;
        gbc.gridx = 0;
        centro.add(crearLabel("Venue:"), gbc);
        gbc.gridx = 1;
        centro.add(comboVenues, gbc);

        // Localidad
        gbc.gridy++;
        gbc.gridx = 0;
        centro.add(crearLabel("Localidad:"), gbc);
        gbc.gridx = 1;
        centro.add(comboLocalidades, gbc);

        // Tiquete
        gbc.gridy++;
        gbc.gridx = 0;
        centro.add(crearLabel("Tiquete disponible:"), gbc);
        gbc.gridx = 1;
        centro.add(comboTiquetes, gbc);
        
        // Precio del tiquete seleccionado
        gbc.gridy++;
        gbc.gridx = 0;
        centro.add(crearLabel("Precio:"), gbc);
        gbc.gridx = 1;
        centro.add(lblPrecioSeleccionado, gbc);

        // Botón comprar
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton btnComprar = new JButton("Comprar");
        btnComprar.setBackground(NARANJA);
        btnComprar.setForeground(Color.WHITE);
        btnComprar.setFocusPainted(false);
        btnComprar.setFont(new Font("Arial", Font.BOLD, 14));
        btnComprar.addActionListener(e -> realizarCompra());

        comboTiquetes.addActionListener(e -> actualizarPrecioSeleccionado());

        centro.add(btnComprar, gbc);

        add(centro, BorderLayout.CENTER);

        // Cargar datos iniciales
        cargarEventos();
    }
    private void actualizarPrecioSeleccionado() {
        Tiquete t = (Tiquete) comboTiquetes.getSelectedItem();
        if (t != null) {
            lblPrecioSeleccionado.setText(
                    String.format("$%,.2f", t.getPrecio())
            );
        } else {
            lblPrecioSeleccionado.setText("-");
        }
    }

    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 14));
        return lbl;
    }

    private void actualizarSaldo() {
        lblSaldo.setText(String.format("Saldo en plataforma: $%,.2f", cliente.getSaldoPlataforma()));
    }

    private void cargarEventos() {
        comboEventos.removeAllItems();
        if (admin == null || admin.mapa_eventos == null || admin.mapa_eventos.isEmpty()) {
            return;
        }
        for (Evento e : admin.mapa_eventos.values()) {
            comboEventos.addItem(e);
        }
        cargarVenues();
    }

    private void cargarVenues() {
        comboVenues.removeAllItems();
        Evento evento = (Evento) comboEventos.getSelectedItem();
        if (evento == null || evento.getVenues() == null) {
            comboLocalidades.removeAllItems();
            comboTiquetes.removeAllItems();
            return;
        }
        for (Venue v : evento.getVenues()) {
            comboVenues.addItem(v);
        }
        cargarLocalidades();
    }

    private void cargarLocalidades() {
        comboLocalidades.removeAllItems();
        Venue venue = (Venue) comboVenues.getSelectedItem();
        if (venue == null || venue.getLocalidades() == null) {
            comboTiquetes.removeAllItems();
            return;
        }
        for (Localidad loc : venue.getLocalidades()) {
            comboLocalidades.addItem(loc);
        }
        cargarTiquetesDisponibles();
    }

    private void cargarTiquetesDisponibles() {
        comboTiquetes.removeAllItems();
        Localidad loc = (Localidad) comboLocalidades.getSelectedItem();
        if (loc == null || loc.getTiquetes() == null) return;

        for (Tiquete t : loc.getTiquetes()) {
            if (!t.isEstaVendido()) {
                comboTiquetes.addItem(t);
            }
        }
    }

    private void realizarCompra() {
        Tiquete t = (Tiquete) comboTiquetes.getSelectedItem();
        if (t == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay tiquete seleccionado o no hay tiquetes disponibles.",
                    "Información",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (t.isEstaVendido()) {
            JOptionPane.showMessageDialog(this,
                    "Este tiquete ya fue vendido.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        double precio = t.getPrecio();
        if (cliente.getSaldoPlataforma() < precio) {
            JOptionPane.showMessageDialog(this,
                    "Saldo insuficiente para comprar este tiquete.",
                    "Saldo insuficiente",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Actualizar dominio
        cliente.setSaldoPlataforma(cliente.getSaldoPlataforma() - precio);
        t.setEstaVendido(true);
        t.setCliente(cliente);
        cliente.getTiquetes().add(t);

        actualizarSaldo();
        cargarTiquetesDisponibles();

        JOptionPane.showMessageDialog(this,
                "Compra realizada con éxito.\nID tiquete: " + t.getIdentificador(),
                "Compra exitosa",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
