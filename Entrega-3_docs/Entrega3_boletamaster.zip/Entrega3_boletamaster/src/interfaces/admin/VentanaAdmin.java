package interfaces.admin;

import javax.swing.*;
import java.awt.*;
import modelo.Administrador;

public class VentanaAdmin extends JFrame {

    public VentanaAdmin(Administrador admin) {
        setTitle("BoletaMaster - Administrador");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        add(new PanelAdmin(admin), BorderLayout.CENTER);
    }
}
