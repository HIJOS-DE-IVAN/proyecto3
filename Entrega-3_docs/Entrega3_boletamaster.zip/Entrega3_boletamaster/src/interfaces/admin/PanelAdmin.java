package interfaces.admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Persistencia.PersistenciaInterfaz;
import java.io.IOException;

import modelo.*;

public class PanelAdmin extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final Color FONDO = new Color(9, 33, 77);
    private static final Color BOTON = new Color(255, 204, 102);

    private final Administrador admin;
    private static final String RUTA_ADMIN = "datos/admin.json";
    private static final String RUTA_CLIENTES = "datos/clientes.json";

    // Paneles derechos
    private JPanel panelOrganizadores;
    private JPanel panelVenues;
    private JPanel panelCancelarEvento;
    private JPanel panelReembolsos;
    private JPanel panelLog;

    public PanelAdmin(Administrador admin) {
        this.admin = admin;

        setBackground(FONDO);
        setLayout(null);

        JLabel lblTitulo = new JLabel("Panel de Administración");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 25));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(150, 10, 400, 40);
        add(lblTitulo);

        // --------- Botones menú izquierdo ---------
        JButton btnOrganizadores = new JButton("Aprobar organizadores");
        btnOrganizadores.setFont(new Font("Arial", Font.PLAIN, 13));
        btnOrganizadores.setBounds(30, 70, 180, 40);
        btnOrganizadores.setBackground(BOTON);
        add(btnOrganizadores);

        JButton btnVenues = new JButton("Aprobar venues");
        btnVenues.setFont(new Font("Arial", Font.PLAIN, 13));
        btnVenues.setBounds(30, 120, 180, 40);
        btnVenues.setBackground(BOTON);
        add(btnVenues);

        JButton btnCancelarEvento = new JButton("Cancelar eventos");
        btnCancelarEvento.setFont(new Font("Arial", Font.PLAIN, 13));
        btnCancelarEvento.setBounds(30, 170, 180, 40);
        btnCancelarEvento.setBackground(BOTON);
        add(btnCancelarEvento);

        JButton btnReembolsos = new JButton("Aprobar reembolsos");
        btnReembolsos.setFont(new Font("Arial", Font.PLAIN, 13));
        btnReembolsos.setBounds(30, 220, 180, 40);
        btnReembolsos.setBackground(BOTON);
        add(btnReembolsos);

        JButton btnLog = new JButton("Eliminar del log");
        btnLog.setFont(new Font("Arial", Font.PLAIN, 13));
        btnLog.setBounds(30, 270, 180, 40);
        btnLog.setBackground(BOTON);
        add(btnLog);

        // --------- Paneles derechos ---------
        panelOrganizadores = crearPanelOrganizadores();
        panelOrganizadores.setBounds(230, 70, 430, 320);
        add(panelOrganizadores);

        panelVenues = crearPanelVenues();
        panelVenues.setBounds(230, 70, 430, 320);
        add(panelVenues);

        panelCancelarEvento = crearPanelCancelarEvento();
        panelCancelarEvento.setBounds(230, 70, 430, 320);
        add(panelCancelarEvento);

        panelReembolsos = crearPanelReembolsos();
        panelReembolsos.setBounds(230, 70, 430, 320);
        add(panelReembolsos);

        panelLog = crearPanelLog();
        panelLog.setBounds(230, 70, 430, 320);
        add(panelLog);

        // Mostrar solo uno al inicio
        mostrarSolo(panelOrganizadores);

        // Listeners menú
        btnOrganizadores.addActionListener(e -> mostrarSolo(panelOrganizadores));
        btnVenues.addActionListener(e -> mostrarSolo(panelVenues));
        btnCancelarEvento.addActionListener(e -> mostrarSolo(panelCancelarEvento));
        btnReembolsos.addActionListener(e -> mostrarSolo(panelReembolsos));
        btnLog.addActionListener(e -> mostrarSolo(panelLog));
    }

    // --------------------------------------------------------------------
    // Utilidad: mostrar solo un panel derecho
    // --------------------------------------------------------------------
    private void mostrarSolo(JPanel panel) {
        panelOrganizadores.setVisible(panel == panelOrganizadores);
        panelVenues.setVisible(panel == panelVenues);
        panelCancelarEvento.setVisible(panel == panelCancelarEvento);
        panelReembolsos.setVisible(panel == panelReembolsos);
        panelLog.setVisible(panel == panelLog);
    }

    // --------------------------------------------------------------------
    // 1. APROBAR ORGANIZADORES (promotores marketplace)
    // --------------------------------------------------------------------
    private JPanel crearPanelOrganizadores() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lbl = new JLabel("Organizadores pendientes (marketplace):");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        lbl.setBounds(10, 10, 350, 30);
        panel.add(lbl);

        DefaultListModel<String> modeloLogins = new DefaultListModel<>();

        HashMap<String, OrganizadorDeEventos> solicitantes =
                admin.getSolicitudes_promotor_marketplace();
        if (solicitantes != null) {
            for (String login : solicitantes.keySet()) {
                modeloLogins.addElement(login);
            }
        }

        JList<String> listaLogins = new JList<>(modeloLogins);
        listaLogins.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(listaLogins);
        scroll.setBounds(10, 50, 270, 200);
        panel.add(scroll);

        JButton btnAprobar = new JButton("Aprobar");
        btnAprobar.setBounds(300, 70, 100, 30);
        btnAprobar.setBackground(BOTON);
        panel.add(btnAprobar);

        JButton btnRechazar = new JButton("Rechazar");
        btnRechazar.setBounds(300, 110, 100, 30);
        btnRechazar.setBackground(BOTON);
        panel.add(btnRechazar);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 260, 400, 30);
        panel.add(lblMensaje);

        // Aprobar
        btnAprobar.addActionListener(e -> {
            String loginSeleccionado = listaLogins.getSelectedValue();
            if (loginSeleccionado == null) {
                lblMensaje.setText("Selecciona un organizador");
                return;
            }

            // Mueve de solicitudes → inscritos
            admin.aceptar_promotor(loginSeleccionado);
            guardarCambiosAdmin();

            // Refrescar lista desde el admin
            modeloLogins.clear();
            HashMap<String, OrganizadorDeEventos> nuevosSolicitantes =
                    admin.getSolicitudes_promotor_marketplace();
            if (nuevosSolicitantes != null) {
                for (String login : nuevosSolicitantes.keySet()) {
                    modeloLogins.addElement(login);
                }
            }

            lblMensaje.setText("Organizador '" + loginSeleccionado + "' aprobado");
        });

        // Rechazar
        btnRechazar.addActionListener(e -> {
            String loginSeleccionado = listaLogins.getSelectedValue();
            if (loginSeleccionado == null) {
                lblMensaje.setText("Selecciona un organizador");
                return;
            }

            HashMap<String, OrganizadorDeEventos> solicitudes =
                    admin.getSolicitudes_promotor_marketplace();
            if (solicitudes != null) {
                solicitudes.remove(loginSeleccionado);
                guardarCambiosAdmin();

            }
            modeloLogins.removeElement(loginSeleccionado);

            lblMensaje.setText("Organizador '" + loginSeleccionado + "' rechazado");
        });

        return panel;
    }

    // --------------------------------------------------------------------
    // 2. APROBAR VENUES SUGERIDOS
    // --------------------------------------------------------------------
    private JPanel crearPanelVenues() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lbl = new JLabel("Venues sugeridos:");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        lbl.setBounds(10, 10, 250, 30);
        panel.add(lbl);

        DefaultListModel<String> modeloNombres = new DefaultListModel<>();

        HashMap<String, Venue> sugeridos = admin.getMapa_venues_sugeridos();
        if (sugeridos != null) {
            for (String nombre : sugeridos.keySet()) {
                modeloNombres.addElement(nombre);
            }
        }

        JList<String> lista = new JList<>(modeloNombres);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(lista);
        scroll.setBounds(10, 50, 270, 200);
        panel.add(scroll);

        JButton btnAprobar = new JButton("Aprobar");
        btnAprobar.setBounds(300, 70, 100, 30);
        btnAprobar.setBackground(BOTON);
        panel.add(btnAprobar);

        JButton btnRechazar = new JButton("Rechazar");
        btnRechazar.setBounds(300, 110, 100, 30);
        btnRechazar.setBackground(BOTON);
        panel.add(btnRechazar);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 260, 400, 30);
        panel.add(lblMensaje);

        btnAprobar.addActionListener(e -> {
            String nombre = lista.getSelectedValue();
            if (nombre == null) {
                lblMensaje.setText("Selecciona un venue");
                return;
            }

            // Aprobar y mover al mapa_venues
            admin.aprobarVenue(nombre);
            guardarCambiosAdmin();


            // Además lo quitamos de sugeridos para no verlo más
            HashMap<String, Venue> mapSugeridos = admin.getMapa_venues_sugeridos();
            if (mapSugeridos != null) {
                mapSugeridos.remove(nombre);
                guardarCambiosAdmin();

            }
            modeloNombres.removeElement(nombre);

            lblMensaje.setText("Venue '" + nombre + "' aprobado");
        });

        // Rechazar = simplemente quitarlo del mapa de sugeridos
        btnRechazar.addActionListener(e -> {
            String nombre = lista.getSelectedValue();
            if (nombre == null) {
                lblMensaje.setText("Selecciona un venue");
                return;
            }

            HashMap<String, Venue> mapSugeridos = admin.getMapa_venues_sugeridos();
            if (mapSugeridos != null) {
                mapSugeridos.remove(nombre);
            }
            modeloNombres.removeElement(nombre);

            lblMensaje.setText("Venue '" + nombre + "' rechazado");
        });

        return panel;
    }

    // --------------------------------------------------------------------
    // 3. CANCELAR EVENTO CUANDO EL ORGANIZADOR LO SOLICITA
    // --------------------------------------------------------------------
    private JPanel crearPanelCancelarEvento() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lbl = new JLabel("Solicitudes de cancelación de eventos:");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 16));
        lbl.setBounds(10, 10, 350, 30);
        panel.add(lbl);

        DefaultListModel<String> modeloEventos = new DefaultListModel<>();

        HashMap<String, String> solicitudes = admin.getMapa_solicitudes();
        if (solicitudes != null) {
            for (String nombreEvento : solicitudes.keySet()) {
                modeloEventos.addElement(nombreEvento);
            }
        }

        JList<String> lista = new JList<>(modeloEventos);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(lista);
        scroll.setBounds(10, 50, 220, 200);
        panel.add(scroll);

        JTextArea txtDescripcion = new JTextArea();
        txtDescripcion.setEditable(false);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
        scrollDescripcion.setBounds(240, 50, 180, 200);
        panel.add(scrollDescripcion);

        JButton btnAprobar = new JButton("Aprobar cancelación");
        btnAprobar.setBounds(10, 260, 180, 30);
        btnAprobar.setBackground(BOTON);
        panel.add(btnAprobar);

        JButton btnRechazar = new JButton("Rechazar solicitud");
        btnRechazar.setBounds(210, 260, 180, 30);
        btnRechazar.setBackground(BOTON);
        panel.add(btnRechazar);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 290, 400, 30);
        panel.add(lblMensaje);

        lista.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String nombreEvento = lista.getSelectedValue();
                if (nombreEvento != null && solicitudes != null) {
                    String desc = solicitudes.get(nombreEvento);
                    txtDescripcion.setText(desc != null ? desc : "(Sin descripción)");
                }
            }
        });

        btnAprobar.addActionListener((ActionEvent e) -> {
            String nombreEvento = lista.getSelectedValue();
            if (nombreEvento == null) {
                lblMensaje.setText("Selecciona un evento");
                return;
            }

            // Cambia el estado del evento a CANCELADO
            admin.aprobar_cancelar_evento(nombreEvento);
            guardarCambiosAdmin();


            // Quitamos la solicitud del mapa para que no vuelva a salir
            HashMap<String, String> mapSolicitudes = admin.getMapa_solicitudes();
            if (mapSolicitudes != null) {
                mapSolicitudes.remove(nombreEvento);
                guardarCambiosAdmin();

            }
            modeloEventos.removeElement(nombreEvento);
            txtDescripcion.setText("");

            lblMensaje.setText("Evento '" + nombreEvento + "' cancelado");
        });

        btnRechazar.addActionListener((ActionEvent e) -> {
            String nombreEvento = lista.getSelectedValue();
            if (nombreEvento == null) {
                lblMensaje.setText("Selecciona un evento");
                return;
            }

            HashMap<String, String> mapSolicitudes = admin.getMapa_solicitudes();
            if (mapSolicitudes != null) {
                mapSolicitudes.remove(nombreEvento);
            }
            modeloEventos.removeElement(nombreEvento);
            txtDescripcion.setText("");

            lblMensaje.setText("Solicitud de cancelación rechazada");
        });

        return panel;
    }

    // --------------------------------------------------------------------
    // 4. APROBAR REEMBOLSOS SOLICITADOS POR CLIENTES
    // --------------------------------------------------------------------
    private JPanel crearPanelReembolsos() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lblTitulo = new JLabel("Aprobar reembolsos de clientes:");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.PLAIN, 16));
        lblTitulo.setBounds(10, 10, 350, 30);
        panel.add(lblTitulo);

        JLabel lblEvento = new JLabel("Nombre del evento:");
        lblEvento.setForeground(Color.WHITE);
        lblEvento.setBounds(10, 60, 150, 25);
        panel.add(lblEvento);

        JTextField txtEvento = new JTextField();
        txtEvento.setBounds(170, 60, 200, 25);
        panel.add(txtEvento);

        JLabel lblCliente = new JLabel("Nombre del cliente:");
        lblCliente.setForeground(Color.WHITE);
        lblCliente.setBounds(10, 100, 150, 25);
        panel.add(lblCliente);

        JTextField txtCliente = new JTextField();
        txtCliente.setBounds(170, 100, 200, 25);
        panel.add(txtCliente);

        JButton btnAprobar = new JButton("Aprobar reembolso");
        btnAprobar.setBounds(10, 150, 180, 30);
        btnAprobar.setBackground(BOTON);
        panel.add(btnAprobar);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 190, 400, 30);
        panel.add(lblMensaje);

        btnAprobar.addActionListener(e -> {
            String nombreEvento = txtEvento.getText().trim();
            String nombreCliente = txtCliente.getText().trim();

            if (nombreEvento.isEmpty() || nombreCliente.isEmpty()) {
                lblMensaje.setText("Ingresa evento y cliente");
                return;
            }

            try {
                admin.aprobar_reembolso(nombreEvento, nombreCliente);
                guardarCambiosClientes();
                guardarCambiosAdmin();
                lblMensaje.setText("Reembolso aprobado para " + nombreCliente + " en " + nombreEvento);
            } catch (Exception ex) {
                lblMensaje.setText("Error al aprobar reembolso: " + ex.getMessage());
            }
        });

        return panel;
    }

    // --------------------------------------------------------------------
    // 5. ELIMINAR UNA OPERACIÓN DEL LOG
    // --------------------------------------------------------------------
    private JPanel crearPanelLog() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(null);

        JLabel lblTitulo = new JLabel("Log de operaciones (solo lectura):");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.PLAIN, 16));
        lblTitulo.setBounds(10, 10, 350, 30);
        panel.add(lblTitulo);

        JTextArea txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);
        JScrollPane scrollLog = new JScrollPane(txtLog);
        scrollLog.setBounds(10, 50, 400, 150);
        panel.add(scrollLog);

        JLabel lblId = new JLabel("ID de operación a eliminar:");
        lblId.setForeground(Color.WHITE);
        lblId.setBounds(10, 210, 200, 25);
        panel.add(lblId);

        JTextField txtId = new JTextField();
        txtId.setBounds(210, 210, 80, 25);
        panel.add(txtId);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(310, 210, 100, 30);
        btnEliminar.setBackground(BOTON);
        panel.add(btnEliminar);

        JLabel lblMensaje = new JLabel("");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setBounds(10, 250, 400, 30);
        panel.add(lblMensaje);

        // Cargar contenido del log
        recargarLogEnTextArea(txtLog);

        btnEliminar.addActionListener(e -> {
            String textoId = txtId.getText().trim();
            if (textoId.isEmpty()) {
                lblMensaje.setText("Ingresa un ID numérico");
                return;
            }
            try {
                int id = Integer.parseInt(textoId);
                admin.eliminar_operacion(id);
                guardarCambiosAdmin();

                lblMensaje.setText("Operación " + id + " eliminada del log");
                recargarLogEnTextArea(txtLog);
            } catch (NumberFormatException ex) {
                lblMensaje.setText("El ID debe ser un número entero");
            } catch (Exception ex) {
                lblMensaje.setText("Error al eliminar: " + ex.getMessage());
            }
        });

        return panel;
    }

    private void recargarLogEnTextArea(JTextArea txtLog) {
        StringBuilder sb = new StringBuilder();
        HashMap<LocalDateTime, Operacion> log = admin.getLog_registros();

        if (log == null || log.isEmpty()) {
            txtLog.setText("No hay operaciones registradas.\n");
            return;
        }

        boolean hayActivas = false;

        for (Map.Entry<LocalDateTime, Operacion> entry : log.entrySet()) {
            LocalDateTime fecha = entry.getKey();
            Operacion op = entry.getValue();

            // Solo mostramos las operaciones activas
            if (!op.esta_activa) {
                continue;
            }

            hayActivas = true;

            sb.append("[")
              .append(fecha)
              .append("] ")
              .append(op.toString())
              .append("\n");
        }

        if (!hayActivas) {
            txtLog.setText("No hay operaciones registradas.\n");
        } else {
            txtLog.setText(sb.toString());
        }
    }
    
    private void guardarCambiosAdmin() {
        try {
            PersistenciaInterfaz.guardarAdministrador(RUTA_ADMIN, admin);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                this,
                "Error al guardar cambios: " + e.getMessage(),
                "Error de Persistencia",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void guardarCambiosClientes() {
        try {
            java.util.HashMap<String, Cliente> mapa = admin.mapa_clientes;

            java.util.List<Cliente> listaClientes = new ArrayList<>();
            if (mapa != null) {
                listaClientes.addAll(mapa.values());
            }

            PersistenciaInterfaz.guardarClientes(RUTA_CLIENTES, listaClientes);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al guardar clientes: " + e.getMessage(),
                    "Error de Persistencia",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }




}
