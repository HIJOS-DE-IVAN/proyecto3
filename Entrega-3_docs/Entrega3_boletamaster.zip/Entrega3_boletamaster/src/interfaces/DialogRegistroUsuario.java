package interfaces;

import javax.swing.*;
import java.awt.*;

public class DialogRegistroUsuario extends JDialog {

    private static final long serialVersionUID = 1L;

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JPasswordField txtConfirmar;
    private JRadioButton rdbCliente;
    private JRadioButton rdbPromotor;
    private JLabel lblError;

    private boolean aceptado = false;

    public DialogRegistroUsuario(JFrame owner) {
        super(owner, "Registro de usuario", true);
        setSize(420, 320);
        setLocationRelativeTo(owner);
        setResizable(false);

        initUI();
    }

    private void initUI() {
        getContentPane().setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        panel.setBackground(new Color(245, 247, 250));
        getContentPane().add(panel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 4, 6, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1;

        int fila = 0;

        JLabel lblTitulo = new JLabel("Crear nueva cuenta");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        gbc.gridy = fila++;
        gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);

        gbc.gridwidth = 1;

        // Usuario
        JLabel lblUsuario = new JLabel("Usuario / login:");
        lblUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        gbc.gridx = 0;
        panel.add(lblUsuario, gbc);

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(txtUsuario, gbc);

        // Contraseña
        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(lblContrasena, gbc);

        txtContrasena = new JPasswordField();
        txtContrasena.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(txtContrasena, gbc);

        // Confirmar contraseña
        JLabel lblConfirmar = new JLabel("Confirmar contraseña:");
        lblConfirmar.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(lblConfirmar, gbc);

        txtConfirmar = new JPasswordField();
        txtConfirmar.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(txtConfirmar, gbc);

        // Tipo de usuario
        JLabel lblTipo = new JLabel("Tipo de usuario:");
        lblTipo.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = fila++;
        panel.add(lblTipo, gbc);

        JPanel panelTipo = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panelTipo.setOpaque(false);
        rdbCliente = new JRadioButton("Cliente");
        rdbPromotor = new JRadioButton("Promotor / Organizador");
        rdbCliente.setSelected(true);
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(rdbCliente);
        grupo.add(rdbPromotor);
        panelTipo.add(rdbCliente);
        panelTipo.add(Box.createHorizontalStrut(12));
        panelTipo.add(rdbPromotor);

        gbc.gridy = fila++;
        panel.add(panelTipo, gbc);

        // Error
        lblError = new JLabel(" ");
        lblError.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblError.setForeground(Color.RED);
        gbc.gridy = fila++;
        panel.add(lblError, gbc);

        // Botones abajo
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 10));

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnRegistrar = new JButton("Registrar");

        panelBotones.add(btnCancelar);
        panelBotones.add(btnRegistrar);

        getContentPane().add(panelBotones, BorderLayout.SOUTH);

        // Listeners
        btnCancelar.addActionListener(e -> {
            aceptado = false;
            dispose();
        });

        btnRegistrar.addActionListener(e -> {
            if (validarFormulario()) {
                aceptado = true;
                dispose();
            }
        });
    }

    private boolean validarFormulario() {
        String usuario = getUsuario();
        String pass = getContrasena();
        String pass2 = getConfirmacion();

        if (usuario.isEmpty()) {
            lblError.setText("El usuario no puede estar vacío.");
            return false;
        }
        if (pass.isEmpty()) {
            lblError.setText("La contraseña no puede estar vacía.");
            return false;
        }
        if (!pass.equals(pass2)) {
            lblError.setText("Las contraseñas no coinciden.");
            return false;
        }
        lblError.setText(" ");
        return true;
    }


    public boolean isAceptado() {
        return aceptado;
    }

    public String getUsuario() {
        return txtUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(txtContrasena.getPassword());
    }

    public String getConfirmacion() {
        return new String(txtConfirmar.getPassword());
    }

    public boolean esCliente() {
        return rdbCliente.isSelected();
    }

    public boolean esPromotor() {
        return rdbPromotor.isSelected();
    }
}
