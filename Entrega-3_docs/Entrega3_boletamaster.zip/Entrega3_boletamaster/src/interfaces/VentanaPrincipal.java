package interfaces;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.*;
import java.util.List;

import Persistencia.PersistenciaInterfaz;

import modelo.Cliente;
import modelo.Administrador;
import modelo.OrganizadorDeEventos;
import modelo.Tiquete;
import interfaces.cliente.VentanaCliente;
import interfaces.admin.VentanaAdmin;
import interfaces.organizador.VentanaOrganizador;

public class VentanaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;

    // Rutas de persistencia
    private static final String RUTA_CLIENTES = "datos/clientes.json";
    private static final String RUTA_ADMIN    = "datos/administrador.json";
    private static final String RUTA_ORGANIZADORES = "datos/organizadores.json";

    // Colores base
    private static final Color COLOR_FONDO_OSCURO = new Color(9, 33, 77);
    private static final Color COLOR_ACENTO = new Color(255, 215, 0);
    private static final Color COLOR_FONDO_CLARO = new Color(245, 247, 250);


    private List<Cliente> clientes;
    private Administrador adminPrincipal;
    private List<OrganizadorDeEventos> organizadores;

    // Componentes de la vista
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JButton btnRegistrarse;
    private JLabel lblError;

    public VentanaPrincipal() {
        setTitle("BoletaMaster - Inicio de sesión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setResizable(false);

        // Inicializamos la capa de datos y la GUI
        initPersistenciaYDatos();
        initComponents();
    }

    // ==================== CARGA ====================

    private void initPersistenciaYDatos() {
        try {
            clientes = PersistenciaInterfaz.cargarClientes(RUTA_CLIENTES);
            adminPrincipal = PersistenciaInterfaz.cargarAdministrador(RUTA_ADMIN, clientes);
            organizadores = PersistenciaInterfaz.cargarOrganizadores(RUTA_ORGANIZADORES, adminPrincipal);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(
                    this,
                    "Error cargando datos de clientes/admin:\n" + e.getMessage(),
                    "Error de persistencia",
                    JOptionPane.ERROR_MESSAGE
            );
            clientes = new ArrayList<>();
            adminPrincipal = null;
        }
    }

    // ==================== INTERFAZ GRÁFICA ====================

    private void initComponents() {
        getContentPane().setLayout(new BorderLayout());

        // --------- Panel IZQUIERDO (brand / bienvenida) ---------
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setBackground(COLOR_FONDO_OSCURO);
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        JLabel lblTituloApp = new JLabel("BoletaMaster");
        lblTituloApp.setForeground(Color.WHITE);
        lblTituloApp.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblTituloApp.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSubtitulo = new JLabel("<html>Gestiona tus eventos,<br>compra y descarga tus tiquetes<br>de forma segura.</html>");
        lblSubtitulo.setForeground(Color.LIGHT_GRAY);
        lblSubtitulo.setFont(new Font("SansSerif", Font.PLAIN, 16));
        lblSubtitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        lblSubtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel barraAmarilla = new JPanel();
        barraAmarilla.setBackground(COLOR_ACENTO);
        barraAmarilla.setMaximumSize(new Dimension(80, 4));
        barraAmarilla.setPreferredSize(new Dimension(80, 4));
        barraAmarilla.setAlignmentX(Component.LEFT_ALIGNMENT);
        barraAmarilla.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        JLabel lblPie = new JLabel("© 2025 BoletaMaster");
        lblPie.setForeground(new Color(200, 200, 200));
        lblPie.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblPie.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblPie.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0));

        panelIzquierdo.add(lblTituloApp);
        panelIzquierdo.add(barraAmarilla);
        panelIzquierdo.add(lblSubtitulo);
        panelIzquierdo.add(Box.createVerticalGlue());
        panelIzquierdo.add(lblPie);

        // --------- Panel DERECHO (formulario) ---------
        JPanel panelDerecho = new JPanel();
        panelDerecho.setBackground(COLOR_FONDO_CLARO);
        panelDerecho.setLayout(new GridBagLayout());
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1;

        JLabel lblBienvenido = new JLabel("Iniciar sesión");
        lblBienvenido.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblBienvenido.setForeground(new Color(30, 30, 30));

        JLabel lblDescripcion = new JLabel("Ingresa con tu cuenta para continuar");
        lblDescripcion.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblDescripcion.setForeground(new Color(100, 100, 100));

        JLabel lblUsuario = new JLabel("Usuario o correo");
        lblUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        JLabel lblContrasena = new JLabel("Contraseña");
        lblContrasena.setFont(new Font("SansSerif", Font.PLAIN, 14));

        txtContrasena = new JPasswordField();
        txtContrasena.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtContrasena.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        lblError = new JLabel(" ");
        lblError.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblError.setForeground(Color.RED);

        btnIngresar = new JButton("Ingresar");
        btnIngresar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnIngresar.setFocusPainted(false);
        btnIngresar.setBackground(COLOR_FONDO_OSCURO);
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnRegistrarse = new JButton("Crear cuenta");
        btnRegistrarse.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btnRegistrarse.setFocusPainted(false);
        btnRegistrarse.setContentAreaFilled(false);
        btnRegistrarse.setBorder(null);
        btnRegistrarse.setForeground(new Color(60, 80, 160));

        // --------- Añadir al panel derecho ------------
        int fila = 0;

        gbc.gridy = fila++;
        panelDerecho.add(lblBienvenido, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(lblDescripcion, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(Box.createVerticalStrut(10), gbc);

        gbc.gridy = fila++;
        panelDerecho.add(lblUsuario, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(txtUsuario, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(lblContrasena, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(txtContrasena, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(lblError, gbc);

        gbc.gridy = fila++;
        panelDerecho.add(btnIngresar, gbc);

        gbc.gridy = fila++;
        gbc.anchor = GridBagConstraints.CENTER;
        panelDerecho.add(btnRegistrarse, gbc);

        // --------- Agregar paneles al frame ---------
        getContentPane().add(panelIzquierdo, BorderLayout.WEST);
        getContentPane().add(panelDerecho, BorderLayout.CENTER);

        // Ajustar ancho del panel izquierdo
        panelIzquierdo.setPreferredSize(new Dimension(320, getHeight()));

        // ================== LISTENERS ==================
        // Login
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manejarLogin();
            }
        });
        // ENTER en contraseña
        txtContrasena.addActionListener(e -> manejarLogin());

        // Registro
        btnRegistrarse.addActionListener(e -> {
            dispose();
            VentanaRegistro v = new VentanaRegistro(clientes, organizadores, adminPrincipal);
            v.setVisible(true);
        });


    }

    // ==================== LOGIN ====================

    private void manejarLogin() {
        limpiarError();
        String user = getUsuario();
        String pass = getContrasena();

        if (user.isEmpty() || pass.isEmpty()) {
            mostrarError("Por favor ingresa usuario y contraseña");
            return;
        }

        // 1. Admin
        Administrador admin = buscarAdmin(user, pass);
        if (admin != null) {
            irComoAdministrador(admin);
            return;
        }

        // 2. Organizador
        OrganizadorDeEventos orga = buscarOrganizador(user, pass);
        if (orga != null) {
        	orga.setAdmin(adminPrincipal);
        	orga.setMapa_eventos(adminPrincipal.getMapa_eventos());
        	orga.setMapa_venues(adminPrincipal.getMapa_venues());
            irComoOrganizador(orga);
            return;
        }

        // 3. Cliente
        Cliente cli = buscarCliente(user, pass);
        if (cli != null) {
            irComoCliente(cli, adminPrincipal);
            return;
        }

        // 4. Nadie
        mostrarError("Usuario o contraseña incorrectos");
    }

    private Administrador buscarAdmin(String login, String pass) {
        if (adminPrincipal != null &&
            adminPrincipal.getLogin().equals(login) &&
            adminPrincipal.getPassword().equals(pass)) {
            return adminPrincipal;
        }
        return null;
    }

    private OrganizadorDeEventos buscarOrganizador(String login, String pass) {
        for (OrganizadorDeEventos o : organizadores) {
            if (o.getLogin().equals(login) && o.getPassword().equals(pass)) {
                return o;
            }
        }
        return null;
    }

    private Cliente buscarCliente(String login, String pass) {
        for (Cliente c : clientes) {
            if (c.getLogin().equals(login) && c.getPassword().equals(pass)) {
                return c;
            }
        }
        return null;
    }

    public void setRegistroAction(ActionListener listener) {
        btnRegistrarse.addActionListener(listener);
    }

    // ==================== REDIRECCIONES ====================

    private void irComoCliente(Cliente cliente, Administrador admin) {

        dispose();
        VentanaCliente v = new VentanaCliente(cliente, admin);
        v.setVisible(true);
    }

    private void irComoAdministrador(Administrador admin) {
        dispose();
        VentanaAdmin ventanaAdmin = new VentanaAdmin(admin);
        ventanaAdmin.setVisible(true);
    }

    private void irComoOrganizador(OrganizadorDeEventos org) {
        dispose();
        VentanaOrganizador v = new VentanaOrganizador(org);
        v.setVisible(true);
    }

    // ==================== HELPERS VISTA ====================

    public String getUsuario() {
        return txtUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(txtContrasena.getPassword());
    }

    public void mostrarError(String mensaje) {
        lblError.setText(mensaje);
    }

    public void limpiarError() {
        lblError.setText(" ");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal v = new VentanaPrincipal();
            v.setVisible(true);
        });
    }
}
